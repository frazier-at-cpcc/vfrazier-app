# Lab 10 Canvas: The 12-Month Implementation Roadmap

Start from your prework roadmap-facts table and your Sessions 2 to 4 artifacts. Finalize the
roadmap that brings this teaching approach to your home institution. The year divides into five
periods, each ending in a decision or an output someone can check. The first 90 days carry the
most detail. Organize the roadmap under the four functions of the NIST AI Risk Management
Framework (Govern, Map, Measure, Manage) so it reads as a plan a chief information officer
recognizes.

## The Five Periods

| Period | Required decision or output | NIST AI RMF function |
| --- | --- | --- |
| Days 1 to 30 | Confirm the sponsor, the target course, the governance path, participant needs, and technical feasibility | |
| Days 31 to 90 | Build or adapt one minimum viable activity, and conduct safety, accessibility, and faculty review | |
| Months 4 to 6 | Pilot with a bounded cohort, and collect performance, verification, workload, and access evidence | |
| Months 7 to 9 | Revise curriculum, support materials, and infrastructure, and decide whether to scale | |
| Months 10 to 12 | Deploy the approved version, report impact, document the maintenance owner, and set the next review date | |

Tag each milestone with the NIST AI RMF function it serves (Govern, Map, Measure, or Manage).

## The Eight Elements

1. **The first course and the first lab.** One course and one activity where the change starts,
   small enough to build in the first 90 days.
2. **The accountable owner.** One person who answers for the milestones. A committee can advise,
   but it cannot be accountable.
3. **The governance checkpoint.** A named review, such as a security or curriculum review, that
   must pass before students use the activity.
4. **The low-cost pilot.** A bounded cohort that tests the activity before anyone commits a
   budget.
5. **Capability milestones.** Each milestone states what the program must be able to do and the
   acceptance criteria that show it can, with any product named only as one example that meets the
   criteria.
6. **The accessibility check.** A scheduled review of keyboard access, captions, text
   alternatives, and a path that needs no paid account, placed against the Title II web
   accessibility compliance dates: **April 26, 2027** for larger public entities and
   **April 26, 2028** for smaller ones.
7. **The evidence of student impact.** The performance evidence the pilot collects and the
   comparison it supports.
8. **The scale-or-stop decision point.** A date, a decision maker, the results that lead to
   scaling, and the results that lead to stopping. A decision point that can only end in scaling is
   not a decision.

## Capability-Milestone Template

> By **(date)**, the **(activity)** can **(capability)**, with acceptance criteria:
> **(tests a reviewer can pass or fail)**. Any product that meets these criteria qualifies.

A product milestone reads "by January, license a code-scanning subscription." A capability
milestone reads "by January, every change to a student-facing endpoint passes an access-control
review that a reproduction confirms, within the Internal data tier, with the model and settings
recorded; any tool that meets these criteria qualifies." If the subscription ends, the capability
milestone still holds.

## Readiness Review

Pairs swap roadmaps and answer two questions in writing. Does every milestone name a capability
and an acceptance criterion a reviewer could check, rather than a product? Can the scale-or-stop
decision point actually end in stopping, with a named result that would stop the work?

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
