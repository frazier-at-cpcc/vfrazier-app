# Example Roadmap: The Network Discovery Lab

A filled canvas built from the track's sample Network Discovery Lab, the same sample Session 4
used in its Lab 8 example. Read it as one worked example, not as the answer to your own roadmap.
Your institution, course, and owner differ.

**The first course and the first lab.** CTS-120 Hardware and Software Support, the Network
Discovery Lab: students map a small subnet with one read-only scan and interpret the output with a
local model, inside a written scope.

**The accountable owner.** The program coordinator for the networking pathway. The curriculum
committee advises; the coordinator answers for the milestones.

## Days 1 to 30 (Govern, Map)

- Confirm the sponsor (the dean of engineering technologies) and the target section.
- Confirm the governance path: the activity goes through the information-security review and the
  curriculum review before any student uses it.
- Gather participant needs: a browser, a range account, and no paid student account.
- Output: a one-page charter naming the sponsor, the owner, and the two review gates.

## Days 31 to 90 (Map, Measure)

- Build one minimum viable activity: the Network Discovery Lab in the range, with a written scope
  and a local-model prompt that stays within the Internal data tier.
- **Governance checkpoint:** the security review must pass before students use the activity. It
  confirms the scope, the data tier, and that no student work leaves the campus environment.
- Conduct the faculty and accessibility review.
- Output: a reviewed lab and a signed security-review record, both before Day 60.

## Months 4 to 6 (Measure)

- **Low-cost pilot:** one section, no budget commitment.
- Collect evidence: completion rate, the share of students who finished with no paid account,
  verification accuracy of the model's output against the captured truth, and workload per student.
- Output: a pilot evidence table.

## Months 7 to 9 (Measure, Manage)

- Revise the lab, the support materials, and the range configuration from the pilot evidence.
- **Scale-or-stop decision point:** by the end of Month 9, the dean decides.
  - **Scale** if the completion rate holds at or above the section's prior lab average, the
    offline-completion rate (students finishing with no paid account) is at least 95 percent, and
    the model's verified output accuracy is at least the agreed threshold.
  - **Stop** if the offline-completion rate falls below 80 percent, or if verification shows the
    model's output misled students in more than one in ten cases. A stop returns the section to the
    prior lab and records why.

## Months 10 to 12 (Govern, Manage)

- Deploy the approved version to the pathway.
- Report impact: the offline-completion rate and the verification accuracy against the prior lab.
- Document the maintenance owner (the program coordinator) and set the next review date.

## Capability Milestones

- By Day 90, the Network Discovery Lab can run entirely on the campus range with no paid student
  account, with acceptance criteria: a student completes it signed in with a range account only;
  the model prompt and its settings are recorded in the Evidence Log; every prompt stays within the
  Internal data tier. Any environment that meets these criteria qualifies.
- By Month 3, the lab passes the accessibility check, with acceptance criteria: keyboard-only
  completion; captions on every video; a text alternative for every figure; a completion path that
  needs no paid account. This check is placed against the Title II dates (**April 26, 2027** for
  larger public entities, **April 26, 2028** for smaller ones), so the accessible path is in place
  before the date that applies to this institution.

## Evidence of Student Impact

The pilot compares the offline-completion rate and the lab completion rate against the same
section's prior network lab, and records the model's verified output accuracy against the captured
truth.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
