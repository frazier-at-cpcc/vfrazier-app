# NITIC AI + Cyber, Session 5: Range Files

These files are installed at `/opt/nitic/session5/` on the lab server, read-only for range
accounts. Everything is synthetic. Northbridge Technical College, the `nb-support-api` repository,
and its people are fictional, every hostname ends in `.example`, and no credential in the code is
live.

## The Patch Is Reviewed, Never Deployed

Pull request 42 runs only inside the lab workstation. You read the diff, run the review methods
against it, and reproduce each concern in the lab's own test environment, which the facilitator
enables at the break. No change reaches any live system. No review tool sends traffic to any
outside address. When you reproduce a concern, you send one request to the local instance on the
workstation, not to any Northbridge host.

## What Is Here

| Path | What it is |
| --- | --- |
| `lab9/review_brief_mensah_2026-11-19.md` | Kwame Mensah's request to review pull request 42 |
| `lab9/data_rules.md` | The pilot data rules |
| `lab9/pr-42.diff` | The pull request: the removed `/backup/` route, the environment-variable change, and the new `GET /aid/status` endpoint |
| `lab9/nb-support-api/` | The repository with the patch applied: application code, `requirements.txt` and lock file, and `tests/` |
| `lab9/review/review_agent.sh` | Sends the diff and a review request to the campus model |
| `lab9/review/sast.sh`, `sca.sh`, `secrets.sh`, `tests.sh` | The static analysis, composition, secret, and test methods |
| `lab9/review/run_local.sh` | Starts the local instance for reproduction (enabled at the break) |
| `lab9/review/recorded/` | Reference outputs each method prints when its tool is not installed |
| `lab9/injects/` | Empty at the start. Two items appear here at the break |
| `lab9/templates/` | Coverage map, finding record, trust-boundary walk, and merge recommendation |
| `lab10/roadmap_canvas.md` | The Lab 10 roadmap canvas |
| `lab10/example_roadmap_networking_lab.md` | A filled example built from the track's sample lab |

## Running the Review Methods

Copy the folder to your home directory first, then run each method from your copy:

```bash
cp -r /opt/nitic/session5/lab9 ~/lab9 && cd ~/lab9
review/review_agent.sh pr-42.diff -- "Review this change for security defects."
review/sast.sh nb-support-api
review/sca.sh nb-support-api
review/secrets.sh nb-support-api
review/tests.sh nb-support-api
```

`sast.sh`, `sca.sh`, and `secrets.sh` run the real tool when it is installed and otherwise print a
reference output from `review/recorded/` under a clear banner. The method reports either way.
`tests.sh` runs the test suite with the Python standard library. `run_local.sh` is disabled until
the break; after the break, `review/run_local.sh start` launches a local instance bound to the
workstation only.

## Data Rule

The code, the diff, and every review output are Confidential. They may go into `review_agent.sh`
and the Open WebUI on this server. They may not go into any hosted AI service. Describe a finding
by its file, function, and line.

## Files Without a Footer

Every file here ends with the training-material line below, except `pr-42.diff` and
`requirements.lock`. The diff stays a valid unified patch and the lock file stays a valid pinned
requirements list.

## Verifying the Copy

`SHA256SUMS` lists every file in this folder. Run
`cd /opt/nitic/session5 && sha256sum -c SHA256SUMS` to verify.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
