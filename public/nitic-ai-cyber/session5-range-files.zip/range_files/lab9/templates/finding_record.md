# Finding Record

One block per concern. Fill every field. Keep a block for each false positive as well as each
finding; a false positive deleted without a record returns at the next scan.

## Concern 1

- **Location:** file, function, and line.
- **Class:** the defect class (for example OWASP A01 broken access control, CWE-117 log injection).
- **Triggering conditions:** what has to be true for the concern to occur.
- **Reproduction:** the exact request sent to the local instance, or the data path traced in the
  source.
- **Observed result:** what happened.
- **Expected result:** what should have happened.
- **Impact:** what an attacker or a mistake could do.
- **Source method and time:** which method raised it, with the tool version or model and the time.
- **Verdict:** finding or false positive.
- **Reason:** the evidence behind the verdict. For a false positive, why it does not apply.

## Concern 2

- **Location:**
- **Class:**
- **Triggering conditions:**
- **Reproduction:**
- **Observed result:**
- **Expected result:**
- **Impact:**
- **Source method and time:**
- **Verdict:**
- **Reason:**

Copy this block for each additional concern.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
