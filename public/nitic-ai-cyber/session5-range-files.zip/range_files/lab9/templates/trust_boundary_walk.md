# Trust-Boundary Walk

A trust boundary is a point where data or control passes between parts of a system that are
trusted to different degrees. Whatever crosses a boundary needs a check on the far side. For each
boundary, mark whether pull request 42 touches it and name the control it needs.

| Boundary | What crosses it | Does pr-42 touch it? | Control it needs |
| --- | --- | --- | --- |
| Data | Request fields, stored records | | |
| Prompt | Text assembled into a model prompt | | |
| Retrieval | Content fetched and fed to a model or a page | | |
| Model | The model's output returned to the caller | | |
| Tool | An action the system takes on the caller's behalf | | |
| Identity | The identity an action runs as | | |
| Memory | State carried between requests or sessions | | |
| Output | Data written to a log, a page, or a downstream reader | | |

**The hinge for this patch.** The `GET /aid/status` endpoint crosses the **Identity** boundary.
The design question is whether the lookup runs as the signed-in student or as a service account
that can read every student's record. The `/search` handler crosses the **Output** boundary: it
writes a request field into the application log, where the campus triage assistant reads it later.

The catalogs for these risks are the OWASP Top 10 for Large Language Model and Generative AI
Applications and the OWASP Top 10 for Agentic Applications.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
