# Coverage Map

One row per change area, one column per review method. In each cell, record what the method
reported, its version or settings, the time it ran, and whether the report became a finding (F) or
a false positive (FP). Leave a cell blank when the method did not examine that area. The last row
is for any area that no automated method examined.

| Change area | Coding-agent review | Static analysis (SAST) | Composition (SCA) | Secret scanning | Tests |
| --- | --- | --- | --- | --- | --- |
| `GET /aid/status` endpoint (`app.py`) | | | | | |
| `/search` handler (`app.py`, `db.py`) | | | | | |
| `config.py` credentials | | | | | |
| Dependencies (`requirements.lock`) | | | | | |
| The test suite (`tests/`) | | | | | |
| Area no automated method examined | | | | | |

**How to read the map.** A column shows what one method covers. A row shows how many methods
looked at one area. The cell that matters most is the change area that only the coding-agent
review or a human read examined. Name it, and state why each automated method missed it.

**Record for each run:** method, tool and version or model and settings, the time in UTC, and
whether the report is a finding or a false positive. A report is not a result until you have
reproduced it or traced its data path.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
