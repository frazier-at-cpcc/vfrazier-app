# Pilot Data Rules

The code in `nb-support-api`, the diff `pr-42.diff`, and every review output you produce are
**Confidential** under the Northbridge interim AI data use policy.

1. The code and its review outputs stay on the lab workstation and the campus AI server. They may
   go into `review/review_agent.sh` and into the Open WebUI chat panel, because both run on the
   campus AI server.
2. Never paste the code, a diff, or a review output into any hosted AI service or any service
   outside the campus environment.
3. Describe a finding by its file, its function, and its line. Do not quote a credential value.
4. Keep your working copies in your range home directory. Copy `lab9` to `~/lab9` and work there.
5. The patch is reviewed, never deployed. Reproduction runs only against the local instance on
   the workstation, bound to the loopback address. No review tool sends traffic to any outside
   address.

A review output that leaves the campus environment is a data-rule break. Note it in your finding
record and tell the facilitator. It is scored as a professional competency, not a penalty.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
