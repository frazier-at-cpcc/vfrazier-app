"""Tests for configuration loading.

TEST_DB_PASSWORD below is a placeholder used only to exercise the override reader. It is not
a live credential and it is never used against any real database.
"""
import unittest

import config

# Placeholder fixture, not a real secret.
TEST_DB_PASSWORD = "test-only-not-real"


class ConfigTest(unittest.TestCase):
    def test_api_key_is_present(self):
        self.assertTrue(config.API_KEY)

    def test_db_name_default(self):
        self.assertEqual(config.DB_NAME, "nb_support")


if __name__ == "__main__":
    unittest.main()

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
