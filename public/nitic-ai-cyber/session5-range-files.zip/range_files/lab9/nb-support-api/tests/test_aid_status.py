"""Happy-path tests for the aid-status endpoint.

A signed-in student can read their own aid letter. These tests assert the normal case only:
they do not assert what happens when a signed-in student requests another student's id.
"""
import json
import threading
import unittest
import urllib.request

import app


class AidStatusTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = app.make_server("127.0.0.1", 0)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def _url(self, path):
        return "http://127.0.0.1:" + str(self.port) + path

    def login(self, student_id):
        body = json.dumps({"student_id": student_id}).encode()
        req = urllib.request.Request(self._url("/login"), body, {"Content-Type": "application/json"})
        with urllib.request.urlopen(req) as resp:
            cookie = resp.headers.get("Set-Cookie")
        return cookie.split(";")[0]

    def test_signed_in_student_reads_own_letter(self):
        cookie = self.login("student_a")
        req = urllib.request.Request(self._url("/aid/status"), headers={"Cookie": cookie})
        with urllib.request.urlopen(req) as resp:
            self.assertEqual(resp.status, 200)
            data = json.loads(resp.read())
        self.assertEqual(data["student_id"], "student_a")
        self.assertIn("Pell Grant", data["letter"])

    def test_unauthenticated_request_is_rejected(self):
        req = urllib.request.Request(self._url("/aid/status"))
        with self.assertRaises(urllib.error.HTTPError) as caught:
            urllib.request.urlopen(req)
        self.assertEqual(caught.exception.code, 401)


if __name__ == "__main__":
    unittest.main()

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
