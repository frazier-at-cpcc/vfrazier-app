# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
