"""Happy-path tests for the search endpoint.

These assert that a normal query returns results and that an allowed sort column works.
They do not send a crafted sort value and they do not assert anything about the log line.
"""
import json
import threading
import unittest
import urllib.request

import app


class SearchTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.httpd = app.make_server("127.0.0.1", 0)
        cls.port = cls.httpd.server_address[1]
        cls.thread = threading.Thread(target=cls.httpd.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()

    def _get(self, path):
        with urllib.request.urlopen("http://127.0.0.1:" + str(self.port) + path) as resp:
            return resp.status, json.loads(resp.read())

    def test_default_search_returns_results(self):
        status, data = self._get("/search?q=aid")
        self.assertEqual(status, 200)
        self.assertTrue(any("Aid" in r["title"] or "FAFSA" in r["title"] for r in data["results"]))

    def test_sort_by_allowed_column(self):
        status, data = self._get("/search?q=a&sort=year")
        self.assertEqual(status, 200)
        self.assertEqual(data["sort"], "year")


if __name__ == "__main__":
    unittest.main()

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
