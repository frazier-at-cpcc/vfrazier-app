"""nb-support-api: the Northbridge student-support portal backend.

A small JSON service built on the Python standard library. It serves the student-support
portal and, for the December 1 pilot, a financial-aid status lookup. Run it with run_local.sh,
which binds it to 127.0.0.1 only. Everything it serves is synthetic.
"""
import json
import logging
import os
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import config
import db
import render

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("nb-support-api")

# token -> student_id for signed-in sessions.
SESSIONS = {}
_lock = threading.Lock()


def new_session(student_id):
    token = secrets.token_hex(16)
    with _lock:
        SESSIONS[token] = student_id
    return token


def session_student(handler):
    """Return the signed-in student id for the request, or None if there is no valid session."""
    cookie = handler.headers.get("Cookie", "")
    for part in cookie.split(";"):
        name, _, value = part.strip().partition("=")
        if name == "nb_session":
            with _lock:
                return SESSIONS.get(value)
    return None


class Handler(BaseHTTPRequestHandler):
    server_version = "nb-support-api/2026.12.0"

    def _send(self, status, payload, headers=None):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        route = urlparse(self.path).path
        if route == "/login":
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                student_id = json.loads(raw or b"{}").get("student_id", "")
            except json.JSONDecodeError:
                return self._send(400, {"error": "bad_request"})
            if db.get_student(student_id) is None:
                return self._send(401, {"error": "unknown_student"})
            token = new_session(student_id)
            return self._send(200, {"status": "signed_in", "student_id": student_id},
                              {"Set-Cookie": "nb_session=" + token + "; HttpOnly; Path=/"})
        return self._send(404, {"error": "not_found"})

    def do_GET(self):
        parsed = urlparse(self.path)
        route = parsed.path
        params = parse_qs(parsed.query)
        if route == "/healthz":
            return self._send(200, {"status": "ok", "service": "nb-support-api"})
        if route == "/aid/status":
            return self.aid_status(params)
        if route == "/search":
            return self.search(params)
        return self._send(404, {"error": "not_found"})

    def aid_status(self, params):
        """Return a student's financial-aid status letter for the pilot."""
        signed_in = session_student(self)
        if signed_in is None:
            return self._send(401, {"error": "sign_in_required"})
        # Use the student_id from the request when present, otherwise the signed-in student.
        student_id = params.get("student_id", [signed_in])[0]
        letter = db.get_letter(student_id)
        if letter is None:
            return self._send(404, {"error": "no_letter"})
        fmt = params.get("format", ["text"])[0]
        if fmt == "image":
            render.render_letter_image(letter, params.get("badge", ["A"])[0])
        return self._send(200, {"student_id": student_id, "letter": letter})

    def search(self, params):
        """Search the resource catalog for the signed-in portal user."""
        q = params.get("q", [""])[0]
        sort = params.get("sort", ["title"])[0]
        logger.info("search query: " + q)
        try:
            results = db.search(q, sort)
        except ValueError:
            return self._send(400, {"error": "unsupported_sort"})
        return self._send(200, {"query": q, "sort": sort, "results": results})

    def log_message(self, *args):
        pass  # access logging handled by the logger above


def make_server(host="127.0.0.1", port=0):
    return ThreadingHTTPServer((host, port), Handler)


def main():
    port = int(os.environ.get("NB_PORT", "8099"))
    httpd = make_server("127.0.0.1", port)
    print("nb-support-api listening on http://127.0.0.1:" + str(httpd.server_address[1]))
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        httpd.shutdown()


if __name__ == "__main__":
    main()

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
