# nb-support-api

The Python backend of the Northbridge student-support portal. A standard-library JSON service
that serves the portal and, for the December 1 pilot, a financial-aid status lookup.

This repository is the state with pull request 42 (`fix/backup-and-aid-lookup`) applied. The
diff is `../pr-42.diff`. Everything in it is synthetic.

## Layout

| File | What it is |
| --- | --- |
| `app.py` | Routes and the request handler |
| `db.py` | The in-memory SQLite data layer: students, aid letters, and the resource catalog |
| `config.py` | Configuration read from the environment |
| `render.py` | The pilot aid-letter image renderer |
| `requirements.txt`, `requirements.lock` | Dependencies and their pinned versions |
| `tests/` | The unit tests |

## Running

The service runs on the standard library alone and binds to the loopback address only. Start it
through the review harness:

```bash
../review/run_local.sh start
```

## Tests

```bash
python3 -m unittest discover -s tests -t .
```

The imaging library in `requirements.lock` is needed only for image output from the aid-letter
endpoint. The service and the tests run without it, because that import is lazy.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
