"""Configuration for nb-support-api.

Secrets come from the environment. The database password is read from NB_DB_PASSWORD
with no fallback, so a missing value fails loudly instead of running with a known default.
"""
import os

# Database credential: read from the environment, no hardcoded default (set by pull request 42).
DB_HOST = os.environ.get("NB_DB_HOST", "127.0.0.1")
DB_NAME = os.environ.get("NB_DB_NAME", "nb_support")
DB_USER = os.environ.get("NB_DB_USER", "nb_support_ro")
DB_PASSWORD = os.environ.get("NB_DB_PASSWORD")

# Service API key. The environment value is used when present; the fallback literal is the
# Session 4 key that was never rotated. Replace the default and remove this fallback.
API_KEY = os.environ.get("NB_API_KEY", "nbk_SYNTHETIC_s4_do_not_use_1a2b3c4d5e")

# Where the aid-letter template lives, for the pilot letter renderer.
LETTER_TEMPLATE = os.environ.get("NB_LETTER_TEMPLATE", "templates/aid_letter.png")


def load_overrides(path):
    """Read an optional YAML overrides file. Only the safe loader is used; the full
    yaml.load loader is never called. The import is lazy so the service runs without PyYAML."""
    import yaml  # lazy
    with open(path) as fh:
        return yaml.safe_load(fh) or {}

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
