"""In-memory data layer for nb-support-api.

A small SQLite database holds the seeded students, their financial-aid status letters,
and the resource catalog the search endpoint reads. Everything here is synthetic.
"""
import sqlite3
import threading

# The only column names the search endpoint is allowed to sort by.
SORT_COLUMNS = ("title", "category", "year")

_local = threading.local()

STUDENTS = [
    ("student_a", "Avery Nolan"),
    ("student_b", "Blake Rivera"),
    ("student_c", "Casey Donovan"),
]

LETTERS = {
    "student_a": "Awarded: Pell Grant 3,200 and Northbridge Opportunity Grant 1,000 for spring.",
    "student_b": "Pending: verification documents required before any award is released.",
    "student_c": "Awarded: Pell Grant 1,750 for spring; work-study offer declined.",
}

RESOURCES = [
    ("Completing the FAFSA", "financial-aid", 2026),
    ("Tutoring Center Hours", "academic-support", 2026),
    ("Payment Plan Options", "billing", 2025),
    ("Appealing an Aid Decision", "financial-aid", 2026),
    ("Disability Services Intake", "accessibility", 2025),
]


def _conn():
    """One SQLite connection per thread, built on first use."""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = sqlite3.connect(":memory:")
        conn.execute("CREATE TABLE students (id TEXT PRIMARY KEY, name TEXT)")
        conn.execute("CREATE TABLE letters (student_id TEXT PRIMARY KEY, letter TEXT)")
        conn.execute("CREATE TABLE resources (title TEXT, category TEXT, year INTEGER)")
        conn.executemany("INSERT INTO students VALUES (?, ?)", STUDENTS)
        conn.executemany("INSERT INTO letters VALUES (?, ?)", list(LETTERS.items()))
        conn.executemany("INSERT INTO resources VALUES (?, ?, ?)", RESOURCES)
        conn.commit()
        _local.conn = conn
    return conn


def get_student(student_id):
    row = _conn().execute("SELECT id, name FROM students WHERE id = ?", (student_id,)).fetchone()
    return None if row is None else {"id": row[0], "name": row[1]}


def get_letter(student_id):
    """Return the aid letter for a student id, or None. The id is bound as a parameter."""
    row = _conn().execute("SELECT letter FROM letters WHERE student_id = ?", (student_id,)).fetchone()
    return None if row is None else row[0]


def search(q, sort):
    """Search the resource catalog. The query term is bound as a parameter; the sort column
    is checked against SORT_COLUMNS before it is placed in the ORDER BY clause."""
    if sort not in SORT_COLUMNS:
        raise ValueError("unsupported sort column")
    sql = "SELECT title, category, year FROM resources WHERE title LIKE ? ORDER BY " + sort
    rows = _conn().execute(sql, ("%" + q + "%",)).fetchall()
    return [{"title": r[0], "category": r[1], "year": r[2]} for r in rows]

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
