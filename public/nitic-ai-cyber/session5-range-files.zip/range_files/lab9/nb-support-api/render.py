"""Aid-letter renderer for the December 1 pilot.

When a caller asks for the aid letter as an image, this module composes the letter text
onto the award template with the Python Imaging Library (Pillow). The import is lazy so the
JSON service and its tests run on a workstation that has no imaging library installed.
"""


def render_letter_image(letter_text, badge_expr="A"):
    """Compose the aid letter onto the template and return the image.

    badge_expr selects the award-tier badge shading and is evaluated against the template
    band A. Pillow's ImageMath.eval performs the evaluation.
    """
    from PIL import Image, ImageMath  # lazy: only imported when an image is requested

    template = Image.open("templates/aid_letter_band.png").convert("L")
    # ImageMath.eval renders the badge band from the tier expression.
    band = ImageMath.eval(badge_expr, A=template)
    return band


def render_letter_text(letter_text):
    """Plain-text fallback used when no imaging library is available."""
    return letter_text

# TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
