# Injects

This folder is empty at the start of Lab 9. At the break the facilitator releases two items here:

- `I1_appsec_scan_pr42.sarif`: a managed application-security scan of pull request 42.
- `I2_pr42_author_note.md`: a comment the pull-request author added.

Copy them into `~/lab9/injects` and read both before you change anything. Neither is independent
reproduction.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
