#!/usr/bin/env bash
# sca.sh PATH : software composition analysis over the lock file.
#
#   review/sca.sh .
#
# Runs pip-audit (or osv-scanner) when installed. When neither is present, prints the recorded
# reference output. The real-tool path and the recorded path report the same planted items.
set -euo pipefail
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
REPO="${1:-.}"
LOCK="$REPO/requirements.lock"
if command -v pip-audit >/dev/null 2>&1; then
  echo "== sca.sh | pip-audit $(pip-audit --version 2>/dev/null | head -1)"
  exec pip-audit -r "$LOCK"
fi
if command -v osv-scanner >/dev/null 2>&1; then
  echo "== sca.sh | osv-scanner $(osv-scanner --version 2>/dev/null | head -1)"
  exec osv-scanner --lockfile "$LOCK"
fi
echo "[recorded output: pip-audit is not installed on this workstation]"
cat "$HERE/recorded/sca.txt"
