#!/usr/bin/env bash
# sast.sh PATH : static analysis over the patched repository.
#
#   review/sast.sh .
#
# Runs Semgrep when it is installed. When it is not, prints the recorded reference output so the
# method still reports. The real-tool path and the recorded path report the same planted items.
set -euo pipefail
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
REPO="${1:-.}"
if command -v semgrep >/dev/null 2>&1; then
  echo "== sast.sh | semgrep $(semgrep --version 2>/dev/null | head -1)"
  exec semgrep --config auto --config p/python "$REPO"
fi
echo "[recorded output: semgrep is not installed on this workstation]"
cat "$HERE/recorded/sast.txt"
