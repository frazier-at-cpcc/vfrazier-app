#!/usr/bin/env bash
# review_agent.sh: ask the campus model to review a proposed code change for security defects.
#
#   review/review_agent.sh ../pr-42.diff -- "Review this change for security defects."
#   review/review_agent.sh --small ../pr-42.diff -- "Rank the concerns, most serious first."
#   review/review_agent.sh --show-prompt ../pr-42.diff -- "..."   # print the prompt and exit
#
# The diff and any extra files are wrapped and sent to the local model with a review rubric as the
# system prompt. Every file must be inside a lab9 folder. Nothing is sent to any outside address.
#   --small         use $SMALL_MODEL (default gemma3:4b) instead of $LARGE_MODEL (default gpt-oss:20b)
#   --show-prompt   print the full prompt the model receives, then exit without running it
#   --thinking      also print the model's reasoning (gpt-oss only)
set -euo pipefail
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
MODEL="${LARGE_MODEL:-gpt-oss:20b}"
export THINK="${THINK:-low}"
SHOW_PROMPT=0
FILES=()
while [ $# -gt 0 ]; do
  case "$1" in
    --small) MODEL="${SMALL_MODEL:-gemma3:4b}"; shift ;;
    --show-prompt) SHOW_PROMPT=1; shift ;;
    --thinking) export SHOW_THINKING=1; shift ;;
    -h|--help) sed -n '2,13p' "$0"; exit 0 ;;
    --) shift; break ;;
    *) FILES+=("$1"); shift ;;
  esac
done
QUESTION="$*"
[ ${#FILES[@]} -gt 0 ] && [ -n "$QUESTION" ] || { echo 'usage: review_agent.sh [--small] [--show-prompt] FILE [FILE...] -- "question"' >&2; exit 2; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/system" <<'SYS'
You are reviewing a proposed code change for security defects. Use only the diff and the files provided. Separate what the code does from what you infer. For each concern, give the file and line, the class of defect, how to reproduce it, and whether an automated rule would see it. Do not claim a defect you cannot point to in the code.
SYS
: > "$TMP/user"
LIST=""
for s in "${FILES[@]}"; do
  [ -f "$s" ] || { echo "review_agent.sh: no file $s" >&2; exit 1; }
  real="$(readlink -f "$s")"
  case "$real" in */lab9/*) ;; *) echo "review_agent.sh: $s is outside a lab9 folder. Copy it into ~/lab9 first." >&2; exit 1 ;; esac
  name="${real#*/lab9/}"
  { echo "<diff file=\"$name\">"; cat "$real"; echo "</diff>"; echo; } >> "$TMP/user"
  LIST="$LIST   $name  sha256=$(sha256sum "$real" | cut -c1-64)  lines=$(wc -l < "$real" | tr -d ' ')"$'\n'
done
cat >> "$TMP/user" <<'ASK'
List the security concerns in this change, most serious first. For each, give the file and line, the class of defect, how a reviewer would reproduce it, and whether a static-analysis rule, a dependency check, or a secret scanner would see it. Mark each concern finding-candidate or needs-reproduction. Call out any required check that the change does not perform.
ASK
printf '\nQuestion: %s\n' "$QUESTION" >> "$TMP/user"

echo "== review_agent.sh | model: $MODEL"
echo "== time: $(date -u '+%Y-%m-%d %H:%M:%S UTC') | $(TZ=America/New_York date '+%Y-%m-%d %H:%M:%S %Z')"
echo "== inputs (${#FILES[@]}):"; printf '%s' "$LIST"
echo "== question: $QUESTION"
if [ "$SHOW_PROMPT" = 1 ]; then echo "== system prompt:"; cat "$TMP/system"; echo "== user message:"; cat "$TMP/user"; exit 0; fi
echo "== answer:"
python3 "$HERE/llm_chat.py" "$MODEL" "$TMP/system" "$TMP/user"
