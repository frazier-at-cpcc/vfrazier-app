#!/usr/bin/env bash
# run_local.sh start|login|request|stop : a loopback-only test environment for reproducing concerns.
#
#   review/run_local.sh start                              # start the patched app on 127.0.0.1
#   review/run_local.sh login student_a                    # sign in as a seeded test student
#   review/run_local.sh request "/aid/status?student_id=student_b"   # send one authorized GET
#   review/run_local.sh stop                               # stop the instance
#
# The instance binds to 127.0.0.1 only. It never sends traffic to any outside address. It is
# installed disabled; the facilitator enables it at the break with release.sh injects, which writes
# the enable flag. (Honor system: NB_LOCAL_ENABLE=1 also enables it.)
set -euo pipefail
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
APP_DIR="$(cd "$HERE/../nb-support-api" && pwd)"
PORT="${NB_PORT:-8099}"
STATE="$HOME/.nb_support_local"
FLAG="${NB_ENABLE_FLAG:-/opt/nitic/session5/lab9/.run_local_enabled}"
CMD="${1:-}"

enabled() { [ "${NB_LOCAL_ENABLE:-0}" = "1" ] || [ -f "$FLAG" ]; }

enabled || { echo "run_local.sh: the test environment opens at the break."; exit 3; }
mkdir -p "$STATE"

case "$CMD" in
  start)
    if [ -f "$STATE/pid" ] && kill -0 "$(cat "$STATE/pid")" 2>/dev/null; then
      echo "already running at http://127.0.0.1:$(cat "$STATE/port" 2>/dev/null || echo "$PORT")"; exit 0
    fi
    # Detach the server from the launching shell: redirect all three std streams away
    # from the terminal/SSH channel and disown it, so `start` returns at once instead of
    # the shell (or an SSH session) waiting on the long-lived server. $! stays the real
    # server PID so `stop` can kill it.
    ( cd "$APP_DIR" && NB_PORT="$PORT" NB_DB_PASSWORD="${NB_DB_PASSWORD:-local-test-not-real}" \
        nohup python3 app.py </dev/null > "$STATE/server.log" 2>&1 & echo $! > "$STATE/pid"; disown "$!" 2>/dev/null || true )
    echo "$PORT" > "$STATE/port"
    for _ in 1 2 3 4 5 6 7 8 9 10; do
      curl -s --max-time 2 -o /dev/null "http://127.0.0.1:$PORT/healthz" && break || sleep 0.3
    done
    echo "nb-support-api is up at http://127.0.0.1:$PORT (loopback only). Reproduce a concern with login and request." ;;
  login)
    STUDENT="${2:-}"; [ -n "$STUDENT" ] || { echo "usage: run_local.sh login <student>"; exit 2; }
    P="$(cat "$STATE/port" 2>/dev/null || echo "$PORT")"
    COOKIE="$(curl -s -i -X POST "http://127.0.0.1:$P/login" -H 'Content-Type: application/json' \
        -d "{\"student_id\":\"$STUDENT\"}" | awk -F'[=;]' 'tolower($0) ~ /set-cookie/ {print $2}')"
    [ -n "$COOKIE" ] || { echo "login failed for $STUDENT (is the instance started, and is $STUDENT a seeded student?)"; exit 1; }
    echo "nb_session=$COOKIE" > "$STATE/cookie"
    echo "signed in as $STUDENT" ;;
  request)
    REQ="${2:-}"; [ -n "$REQ" ] || { echo 'usage: run_local.sh request "/path?query"'; exit 2; }
    P="$(cat "$STATE/port" 2>/dev/null || echo "$PORT")"
    [ -f "$STATE/cookie" ] || { echo "no session; run: run_local.sh login <student>"; exit 1; }
    echo "GET http://127.0.0.1:$P$REQ  (as $(cut -d= -f2 "$STATE/cookie" | cut -c1-8)...)"
    curl -s -i -H "Cookie: $(cat "$STATE/cookie")" "http://127.0.0.1:$P$REQ"
    echo ;;
  stop)
    if [ -f "$STATE/pid" ]; then kill "$(cat "$STATE/pid")" 2>/dev/null || true; rm -f "$STATE/pid"; echo "stopped"; else echo "not running"; fi ;;
  *)
    sed -n '2,13p' "$0"; exit 2 ;;
esac
