#!/usr/bin/env bash
# tests.sh PATH : run the nb-support-api test suite with the Python standard library.
#
#   review/tests.sh .     # from inside nb-support-api
#
# No test framework is required: the suite runs under python3 -m unittest.
set -euo pipefail
REPO="${1:-.}"
[ -d "$REPO/tests" ] || { echo "tests.sh: no tests/ under $REPO" >&2; exit 1; }
echo "== tests.sh | python3 -m unittest discover -s tests -t ."
echo "== python: $(python3 --version 2>&1)"
cd "$REPO"
python3 -m unittest discover -s tests -t . -v
