#!/usr/bin/env bash
# secrets.sh PATH : secret scanning over the repository.
#
#   review/secrets.sh .
#
# Runs gitleaks (or detect-secrets) when installed. When neither is present, prints the recorded
# reference output. The real-tool path and the recorded path report the same planted items.
set -euo pipefail
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
REPO="${1:-.}"
if command -v gitleaks >/dev/null 2>&1; then
  echo "== secrets.sh | gitleaks $(gitleaks version 2>/dev/null | head -1)"
  exec gitleaks detect --source "$REPO" --no-git -v
fi
if command -v detect-secrets >/dev/null 2>&1; then
  echo "== secrets.sh | detect-secrets $(detect-secrets --version 2>/dev/null | head -1)"
  exec detect-secrets scan "$REPO"
fi
echo "[recorded output: gitleaks is not installed on this workstation]"
cat "$HERE/recorded/secrets.txt"
