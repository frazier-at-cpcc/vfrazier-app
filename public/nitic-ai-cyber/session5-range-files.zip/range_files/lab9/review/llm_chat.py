#!/usr/bin/env python3
"""Shared helper for notebook.sh and ask_cve.sh: send one chat to the local Ollama server and stream the answer.

Usage: llm_chat.py MODEL SYSTEM_FILE USER_FILE
Prints the answer, then one stats line (prompt tokens, context length, seconds).
Env: OLLAMA_URL (default http://127.0.0.1:11434), SHOW_THINKING=1 to print the model's reasoning,
     THINK=low|medium|high for gpt-oss models (default low).
"""
import json, os, sys, time, urllib.request

model, sys_file, user_file = sys.argv[1:4]
url = os.environ.get("OLLAMA_URL", "http://127.0.0.1:11434")
body = {"model": model, "stream": True,
        "messages": [{"role": "system", "content": open(sys_file).read()},
                     {"role": "user", "content": open(user_file).read()}]}
if model.startswith("gpt-oss"):
    body["think"] = os.environ.get("THINK", "low")
show_thinking = os.environ.get("SHOW_THINKING") == "1"
t0 = time.time()
req = urllib.request.Request(url + "/api/chat", json.dumps(body).encode(), {"Content-Type": "application/json"})
final, in_thinking = {}, False
try:
    with urllib.request.urlopen(req, timeout=900) as r:
        for raw in r:
            chunk = json.loads(raw)
            if "error" in chunk:
                sys.exit("ollama error: " + chunk["error"])
            msg = chunk.get("message", {})
            if show_thinking and msg.get("thinking"):
                if not in_thinking:
                    print("[model reasoning]", flush=True); in_thinking = True
                print(msg["thinking"], end="", flush=True)
            if msg.get("content"):
                if in_thinking:
                    print("\n[answer]", flush=True); in_thinking = False
                print(msg["content"], end="", flush=True)
            if chunk.get("done"):
                final = chunk
except OSError as e:
    sys.exit(f"cannot reach Ollama at {url}: {e}")
secs = time.time() - t0
ctx = "?"
try:
    with urllib.request.urlopen(url + "/api/ps", timeout=10) as r:
        for m in json.load(r).get("models", []):
            if m.get("name") == model or m.get("model") == model:
                ctx = m.get("context_length", "?")
except OSError:
    pass
ptok = final.get("prompt_eval_count", "?")
print(f"\n\n[stats] model={model} prompt_tokens={ptok} context_length={ctx} seconds={secs:.1f}")
if isinstance(ptok, int) and isinstance(ctx, int) and ptok >= ctx - 2048:
    print("[warning] the prompt nearly fills the context window; the model may not have seen every source or room to answer. Use fewer sources.")
