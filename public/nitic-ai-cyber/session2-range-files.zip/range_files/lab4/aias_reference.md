# Two Frameworks for Deciding Where AI Belongs in an Assignment

Both frameworks below are published and in use at real institutions. The summaries are paraphrased; cite the originals (Student Guide references) in your own syllabus.

## The AI Assessment Scale (AIAS), 2024 Version

Perkins, Furze, Roe, and MacVaugh published the scale in the Journal of University Teaching and Learning Practice (2024); Furze and colleagues revised the level names later that year. The scale is assigned per assessment, not per course, and printed on the assignment so students know the lane before they start.

| Level | Name | What the student may do with AI | What the assessment can still claim to measure |
| --- | --- | --- | --- |
| 1 | No AI | Nothing. The task is completed under conditions where AI use is prevented (in person, supervised, or live). | Unaided performance. The authors note this is the only level where security against AI use is possible. |
| 2 | AI Planning | Brainstorming, outlining, research, and structuring. The submitted work is the student's own. | The student's execution, given ideas that may have been AI-assisted. |
| 3 | AI Collaboration | Drafting, feedback, and refinement with AI, with the student critically evaluating and editing. | Judgment: what the student kept, changed, and rejected, and why. |
| 4 | Full AI | AI completes the task; the student directs it and is accountable for the result. | Direction and evaluation of AI output, not production. |
| 5 | AI Exploration | AI is itself the object of study: students explore its capabilities and limits. | Understanding of the tool. |

Validity is possible at every level if the assessment is designed for that level. Security (certainty that no AI was used) is possible only at Level 1.

## The Two-Lane Approach (University of Sydney)

Bridgeman and Liu proposed two lanes in 2023; the university adopted them as policy for 2025.

| Lane | Purpose | Conditions | Example |
| --- | --- | --- | --- |
| Lane 1: Secured | Assurance that the learning outcome is met by the student | Supervised, in person or live; no aids; used sparingly and for program-level outcomes | Interactive oral exam, live lab practical, invigilated test |
| Lane 2: Open | Assessment for learning; development of skills including AI use | Any tool allowed; AI use acknowledged; process documented | Take-home report with disclosure and process evidence |

The Sydney position worth quoting to a curriculum committee: an unsupervised take-home task labeled "no AI" cannot be secured and cannot be validated, so the label is not a policy.

## How Session 2 Uses Them

Lab 4 asks your team to assign the redesigned Module 6 an AIAS level and a lane, then to make the rubric measure what that level can claim. A Level 3 report graded only on the final text claims more than it can measure. The same report with a process transcript, a disclosure statement, and a five-minute oral check can.
