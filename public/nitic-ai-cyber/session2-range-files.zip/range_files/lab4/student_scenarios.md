# Student Scenarios for Testing Guardrails

Read each scenario against your drafted guardrails. For each, decide: which area applies, what the guardrail says happens, and whether the text is clear enough that the student and the instructor would reach the same conclusion. Where it is not, revise the draft.

## Scenario 1: The Grammar Tool

A student in CYB 110 has used a grammar-checking browser extension since high school. This term the extension added a "rewrite for clarity" button that regenerates whole paragraphs. The student used it on the Module 6 report. The student has no accommodation on file.

## Scenario 2: The Consumer Chatbot and the Log

A student pasted the entire `nbtc-fw01_excerpt.log` into a free consumer chatbot with the lazy prompt and submitted the output with light edits. The log was provided as course material. In the Northbridge story it was also an excerpt from the real campus firewall, handed to the instructor by the network team.

## Scenario 3: Disclosed but Cannot Explain

A student's report ends with "I used ChatGPT to organize and proofread; the analysis is mine." In a five-minute check-in the student cannot say why a connection to port 1433 from a lab workstation matters, although the report's fourth recommendation is about exactly that.

## Scenario 4: The Rule That Worked

A student asked a model to write an nftables rule that blocks SMB from the lab VLAN to the file server, loaded it in the course VM, generated test traffic, captured the dropped packets, and attached the rule, the capture, and the chat export. The student's report says, "I used AI to draft the rule and then tested it."

## Scenario 5: The Instructor and the Detector

The instructor wants to upload all 34 Module 6 reports to a free AI-detection website "just to see." The reports carry student names and ID numbers.

## Scenario 6: The Accommodation Question

A student with an approved extended-time accommodation uses a licensed read-aloud and summarization tool for reading-heavy assignments. The draft syllabus says "AI tools are not permitted on Module 6." The student emails to ask whether the summarizer is allowed and does not want to explain why to the whole class.

## Scenario 7: The Four-Minute Transcript

A student's required `script` transcript shows all commands entered in one burst, with no exploratory commands, no errors, and no corrections, four minutes before the submission timestamp. The report's numbers are all correct.

## Scenario 8: The Group That Shared One Chat

Three students in a study group used one shared chat with the campus AI server to work through the log together, then each wrote their own report. The reports have the same structure and two identical sentences. The chat export shows all three contributing.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
