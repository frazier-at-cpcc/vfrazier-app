# Northbridge Technical College: Interim AI Data Use Policy

Approved by the Provost, Dr. Alicia Harmon, October 23, 2026, on the recommendation of the IT Security Office. Interim for the 2026-27 academic year pending review by the Academic Council.

## 1. Purpose

This policy states where college data may be processed by generative AI tools. It applies to all employees and to any tool, including free consumer tools, campus-hosted tools, and licensed hosted services.

## 2. Data Tiers

| Tier | Examples | Governing law |
| --- | --- | --- |
| Public | Course catalog, published schedules, press releases | None |
| Internal | Department meeting notes, budget drafts, unpublished aggregate reports | College policy |
| Confidential | Security logs, reported phishing emails, personnel matters, aggregate data that could identify individuals in small groups | College policy; contracts |
| Restricted | Education records including student work submitted for a grade, grades, rosters, accommodation letters; financial aid records; SSNs; health information | FERPA (34 CFR Part 99); GLBA Safeguards Rule (16 CFR Part 314); HIPAA where applicable |

## 3. Approved Environments

| Environment | Public | Internal | Confidential | Restricted |
| --- | --- | --- | --- | --- |
| Consumer AI tools (free or personal accounts) | Yes | No | No | No |
| Licensed hosted service (enterprise agreement, no training on inputs, 30-day retention) | Yes | Yes | Yes, with approval of the data owner | No |
| Northbridge AI Server (`ai.northbridge-tc.example`, on campus, Ollama and Open WebUI) | Yes | Yes | Yes | Yes, de-identified where the task allows, with chat history disabled for Restricted data |

## 4. Requirements

1. Restricted data never enters a consumer tool or any service without a college contract. Uploading student work to a third-party website, including AI-detection services, is processing of an education record and requires a contract that meets the FERPA school-official conditions.
2. Any AI output used in a decision about a person (grading, discipline, hiring, aid) must be reviewed by a named employee who records the review.
3. Employees record consequential AI use in a unit log (prompt, model, output, decision).
4. Suspected violations go to the Information Security Office (555-0170) and are handled under the Data Incident Procedure, not as misconduct, during the interim period.

## 5. Scope Note

This policy governs how data is handled. It does not decide whether students may use AI in coursework or how faculty assess student learning. Those questions belong in course syllabi and department assessment standards.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
