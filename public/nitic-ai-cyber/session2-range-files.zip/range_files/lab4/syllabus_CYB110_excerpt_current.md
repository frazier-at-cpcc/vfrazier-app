# CYB 110 Security Concepts, Section 02: Syllabus Excerpt (Fall 2026)

Instructor: Dana Okafor, Computer Technologies Department, Carver Hall 214
Office hours: Tuesday and Thursday 11:00 to 12:30, or by appointment
Course delivery: Online with weekly synchronous session (Wednesday 6:00 to 7:15 p.m.)

## Course Outcomes

Upon completion, students should be able to identify common attacks and recommend appropriate safeguards; apply the CIA triad to institutional scenarios; perform basic account hardening, log review, and packet analysis in a virtual lab environment; and explain the purpose of security policy.

## Academic Integrity

Students are expected to do their own work. Cheating, plagiarism, and the use of unauthorized aids on any assignment, lab, or exam are violations of the Student Code of Conduct (Policy 5.12) and will result in a grade of zero on the assignment and referral to the Dean of Students. A second violation results in failure of the course.

*(This section has not changed since the Spring 2019 syllabus template.)*

## Accommodations

Northbridge Technical College is committed to providing equal access. Students with documented disabilities should contact Accessibility Services (Keller Student Center 118, 555-0142) to arrange accommodations. Please share your accommodation letter with the instructor during the first two weeks of the term.

## Technology Requirements

Students need a computer capable of running the course virtual machines (8 GB RAM minimum) or access to the campus lab in Carver Hall 210. Course VMs are provided through the department's lab portal. Students are responsible for keeping their lab VM snapshots.

## Late Work

Assignments lose 10 percent per day late, up to five days. Labs are not accepted more than one week late.

## Communication

Use the LMS messaging tool for course questions. Expect a response within one business day.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
