# Evidence Examples

Four worked examples of the process evidence the redesigned Module 6 asks for, prepared by the Computer Technologies Department while drafting the redesign (dated November 16 and 17, 2026, after the interim AI data policy approved the campus AI server for student work). They are what a student working the redesigned assignment would hand in, not records of any Fall 2026 submission; the legacy Module 6 asked for none of this.

| File | What it shows |
| --- | --- |
| `typescript_module6_example.txt` | A `script` transcript of a log review: start and end timestamps, every command, a typo, a comment to self |
| `history_timestamped_example.txt` | Shell history with per-command timestamps across two evenings |
| `ai_chat_export_example.md` | An Open WebUI chat export from the campus server: two understanding questions, no text taken into the report |
| `ai_use_disclosure_example.md` | The four-element disclosure form (tools, purpose, extent, oversight), filled in |

TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
