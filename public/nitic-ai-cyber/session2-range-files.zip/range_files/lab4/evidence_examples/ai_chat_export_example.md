# Chat Export: "port 1433 question"

Exported from Open WebUI on the Northbridge AI Server (`ai.northbridge-tc.example`), November 16, 2026, 20:44 EST. Model: gpt-oss:20b. Attached to the Module 6 submission as Appendix B.

---

**User (20:44:10):** In a firewall log, what is TCP port 1433 normally used for, and what would it mean if a workstation on a student lab subnet tried to connect to it on a database server at 3 in the morning? Do not tell me what to write; I am checking my understanding.

**Assistant (20:44:14):** TCP 1433 is the default listening port for Microsoft SQL Server. A connection attempt to it is a client trying to open a database session. From a lab workstation to a production database server, especially outside working hours, the possibilities are roughly: a student or staff member intentionally probing or connecting (authorized testing is rare at that hour and would normally come from an administrative host); malware or a tool on the workstation scanning for database servers; a misconfigured application or scheduled task. Two attempts three seconds apart look more like a deliberate connection attempt or an automated retry than a scan. The firewall dropping it means the attempt was blocked at the network layer; it does not tell you whether the workstation is compromised. The next evidence would come from the workstation itself and from the domain controller's logon events.

**User (20:46:02):** Is SMB (445) from the same lab workstation to a file server at 2:30 am unusual on its own?

**Assistant (20:46:06):** On its own, not necessarily. Lab machines often map a share for coursework, and some agents and backup tools use SMB. It becomes interesting in combination: the same host reaching the file server repeatedly, then Kerberos to the domain controller, then the database port. Sequence and time of day are what make it worth a question, not the protocol.

---

*Student note on the export: I used these two answers to decide which finding to lead with. The counts and times in my report came from grep, not from the model (see transcript).*

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
