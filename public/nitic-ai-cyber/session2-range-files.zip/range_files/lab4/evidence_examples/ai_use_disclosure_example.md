# AI Use Disclosure (Attached to the Module 6 Report)

| | |
| --- | --- |
| Student | (name) |
| Assignment | CYB 110 Module 6: Firewall Log Review and Incident Report |
| AIAS level for this assignment | 3: AI Collaboration |
| Tools used | gpt-oss:20b through Open WebUI on the Northbridge AI Server, October 15, 2026 (chat export attached as Appendix B) |
| Purpose | To check my understanding of what ports 1433 and 445 are used for and whether the sequence of connections from one lab host was unusual |
| Extent | Minimal. Two questions. No text from the model appears in the report. |
| What the AI did not do | It did not see the full log, did not write any part of the report, and did not produce the counts or times |
| My verification | Every number in the report comes from commands in the attached transcript (`module6_typescript.txt`). I re-ran the three counts the day I submitted. |
| Data handling | No student names, IDs, or credentials were entered. The log was course material provided by the instructor. |

I confirm this disclosure is complete and that I can explain any part of the report without notes.

Signature: ____________________  Date: __________

*Format adapted from the four elements of AI attribution in the Elon University and AAC&U Student Guide to AI (2025 edition): tools, purpose, extent, oversight.*
