# Syllabus Guardrails Drafting Template

Draft each of the seven areas in two to five sentences a student can act on. After drafting, test each against at least one scenario in `student_scenarios.md` and record what happened. The Participant Packet has the questions each area must answer; the Student Guide, Part 5, has the law and the examples.

| # | Area | Must answer | Draft | Scenario tested | Result (held / needs revision) |
| --- | --- | --- | --- | --- | --- |
| 1 | Acceptable AI use | Which uses are allowed, which are not, and how a student finds out for a specific assignment (lane or level named per assignment) | | | |
| 2 | Attribution | How AI contributions are credited: in-text, footnote, appendix; which style guide; what counts as a quotation of a model | | | |
| 3 | Disclosure | What a student states about tools, purpose, extent, and oversight; where the statement goes; what happens when a student does not disclose | | | |
| 4 | Prohibited data | What students may never paste into a tool (other people's records, credentials, real campus logs, unpublished course materials, their own ID numbers); which environments are approved | | | |
| 5 | Evidence retention | What process evidence students keep (drafts, transcripts, chat exports, version history), for how long, in what form, and when it may be requested | | | |
| 6 | Accessibility | How approved assistive technology and accommodations relate to the AI rules; who decides; how a student asks without having to disclose a disability to the class | | | |
| 7 | Academic integrity | What counts as a violation, how a concern is raised, what evidence the instructor will and will not rely on (no detector scores as sole basis), the student's opportunity to respond, and the consequence ladder | | | |

Two checks before you finish: (a) nothing here contradicts the interim AI data policy; (b) a student could follow every sentence without guessing.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
