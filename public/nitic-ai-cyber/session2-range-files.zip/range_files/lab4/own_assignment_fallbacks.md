# Fallback Assignments for the Sprint (Lab 4, Stage 4)

Bring one of your own assignments. If you did not, pick one of these two. Both are legacy-style assignments in common use that generative AI completes well.

## Option 1: NET 110 Subnetting Worksheet

"Given the network 172.16.0.0/16, design an addressing plan for a campus with six buildings needing 400, 250, 120, 60, 30, and 10 hosts. For each subnet give the network address, mask, first and last usable host, and broadcast. Show your work. 20 points: 2 per correct subnet row, 8 for the written explanation of your approach."

## Option 2: CYB 110 Module 3: Password Policy Memo

"Write a two-page password and authentication policy for a 40-person accounting firm. Include length, complexity, rotation, lockout, MFA, and password manager guidance. Cite NIST SP 800-63B. 20 points: 10 for completeness, 5 for alignment with NIST, 5 for professional writing."

For either, run the canvas sections A through H in the time available. Section C is where most of the redesign happens: a subnetting plan for a campus whose building list the student draws from a seeded generator, defended live in three minutes, is a different assignment from the same plan handed in on paper.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
