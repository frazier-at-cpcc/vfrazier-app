# Assignment Redesign Canvas

One canvas per assignment. Fill it for Module 6 in Lab 4, Stage 1 and 2, then again for one of your own assignments in Stage 4.

## A. The Competency

What the catalog or course outcome says this assignment measures:

What the legacy version actually measures (from Lab 3):

## B. The Lane

AIAS level (1 to 5) and Sydney lane (secured or open) for this assignment, and the one-sentence reason:

What the student is told, in the assignment text, about what AI may and may not do here:

## C. Authentic Performance

The real artifact a professional produces in this situation (not "a 500-word report" but the thing a SOC analyst hands a shift lead):

The audience and the constraint that make the decision matter (time, budget, one change allowed, a stakeholder who pushes back):

What is unique to each student (a seeded dataset, their own machine, a role, a date) so the task is not interchangeable:

## D. Decision-Making

The decision the student must make and justify, where two defensible answers exist:

How the rubric rewards the justification rather than the answer:

## E. Process Evidence

What the student submits besides the product (transcript, timestamped history, drafts, chat export, screenshots with timestamps):

How the evidence is kept (where, how long, format) and when it is reviewed (always, sample, or on concern):

## F. Technical Validation

The step where the student proves a claim or a fix works (run the rule, replay the traffic, reproduce the count, test the script):

What the validation output looks like and how it is graded:

## G. Student Accountability

The moment the student answers for the work in their own voice (oral check-in, live walkthrough, in-class checkpoint, peer explanation):

Three questions you would ask this student that only the author can answer well:

## H. Rubric Rewrite

| Legacy criterion | Redesigned criterion | Points | What full credit looks like |
| --- | --- | --- | --- |
| | | | |
| | | | |
| | | | |
| | | | |

## I. Cost Check

Instructor minutes per student before and after. If the redesign costs more than you can spend, what is sampled, automated (locally), or moved to class time?
