# NITIC AI + Cyber, Session 2: Range Files

Copy this folder to `/opt/nitic/session2/` on the range host and run `chmod -R a+rX /opt/nitic/session2` so range accounts can read but not modify it. Every file is synthetic and marked as training material. Domains use the reserved `.example` suffix, external IPs use the 198.51.100.0/24 and 203.0.113.0/24 documentation ranges, and phone numbers use 555-01xx. Northbridge Technical College, its staff, students, courses, and policies continue from Session 1.

| Path | Used in |
| --- | --- |
| `lab3/assignment_CYB110_module6_incident_report.md` | Lab 3: the legacy assignment and its rubric |
| `lab3/nbtc-fw01_excerpt.log` | Lab 3: the log the assignment refers to (identical to Session 1 `item5_firewall_excerpt.log`) |
| `lab3/submissions/` | Lab 3, Stage 3: four student submissions (A to D) |
| `lab3/prompts/lazy_prompt.txt`, `solve_costar.md` | Lab 3, Stage 2: the two prompts the team runs |
| `lab3/prompts/detector_prompt.md` | Demo 2; Lab 3 early finishers |
| `lab3/prompts/score_with_legacy_rubric.md` | Demo 5; optional in Lab 3 |
| `lab3/prompts/viva_questions.md` | Demo 4; Lab 4, Stage 2 |
| `lab3/prompts/*.txt` | The same prompts as plain text, for `cat` in the Lab Manual commands |
| `lab4/syllabus_CYB110_excerpt_current.md` | Lab 4: the syllabus to revise |
| `lab4/northbridge_ai_data_policy_interim.md` | Lab 4: the policy the guardrails must not contradict (the Mission 1 memo, adopted) |
| `lab4/aias_reference.md` | Lab 4, Stage 1: the AI Assessment Scale and the two-lane approach |
| `lab4/redesign_canvas.md` | Lab 4, Stages 1, 2, and 4 |
| `lab4/guardrails_template.md`, `student_scenarios.md` | Lab 4, Stage 3 |
| `lab4/evidence_examples/` | Demo 3; Lab 4, Stage 2: a `script` transcript, timestamped history, a chat export, a disclosure statement |
| `lab4/own_assignment_fallbacks.md` | Lab 4, Stage 4, for participants without an assignment of their own |
| `lab4/seeded_log_generator.py` | The per-student log generator the redesigned Module 6 uses (`python3 seeded_log_generator.py N00421331`; `--key` for the planted finding) |

`SHA256SUMS` lists every participant file; `sha256sum -c SHA256SUMS` verifies the copy on the range. Regenerate it after any change to the files (`python3 session2/tools/gen_files.py` does).

The `demos/` folder holds facilitator material, including the submissions key. Leave it off participant-readable paths.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
