# Prompt: Generate Oral-Defense Questions From a Submission

Used in Demo 4 and in Lab 4, Stage 2 (accountability). Run on `LARGE_MODEL` on the campus server only; the submission is an education record.

```
CONTEXT
You are helping a cybersecurity instructor prepare a five-minute oral check-in with a student about the incident report below. The student has already submitted the report. The firewall log the report is based on follows the report.

OBJECTIVE
Write five questions the instructor can ask this specific student that can only be answered well by someone who did the analysis themselves. Each question must refer to a specific claim, number, or recommendation in this student's report.

STYLE
Numbered list. Each question is one or two sentences.

TONE
Neutral and curious, not accusatory. The questions should work equally well for a student who did the work and a student who did not.

AUDIENCE
The instructor, who will ask them aloud.

RESPONSE
Five questions. After each, one line in brackets stating what a strong answer would include and what a weak answer would sound like. Do not state or guess whether the student used AI.

=== REPORT ===
[paste one submission]

=== LOG ===
[paste nbtc-fw01_excerpt.log]
```

Validate the five questions before using them: each should point at something actually in the report (the model will sometimes invent a claim to ask about). Strike any question that does.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
