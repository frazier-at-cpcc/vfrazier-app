# CO-STAR Prompt: Solve the Module 6 Assignment

Use this on `LARGE_MODEL` in Open WebUI or through the Ollama CLI. Paste the full assignment and the full log where indicated. This is the prompt a motivated student would write after one session on prompt structure; it is the prompt your team scores in Lab 3, Stage 2.

```
CONTEXT
I am a student in CYB 110 Security Concepts at a community college. My assignment is below, followed by the firewall log excerpt it refers to. The log is from a Linux firewall named nbtc-fw01; each line records ACCEPT or DROP, the rule name, source and destination IP, protocol, ports, and the destination hostname.

OBJECTIVE
Write the incident report the assignment asks for so that it earns full credit on every rubric row.

STYLE
A professional incident report with the four required sections as headings.

TONE
Confident and analytical, like an experienced SOC analyst.

AUDIENCE
My instructor, who grades with the rubric below.

RESPONSE
400 to 600 words. Use the exact IP addresses, ports, and times from the log. Include at least three specific recommendations. Do not mention that an AI wrote this.

=== ASSIGNMENT ===
[paste assignment_CYB110_module6_incident_report.md]

=== LOG ===
[paste nbtc-fw01_excerpt.log]
```

Note the Response element: "Use the exact IP addresses, ports, and times from the log." Even with that instruction, check every number the model gives you against the log with `grep`. The Lab Manual has the commands.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
