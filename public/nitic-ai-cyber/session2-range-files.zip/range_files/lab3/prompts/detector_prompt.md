# Prompt: Ask a Model Whether a Text Is AI-Written

Used in Demo 2 (Detector Roulette) and by early finishers in Lab 3. Run on `SMALL_MODEL` at the default temperature, three times, each in a fresh chat, with the same text.

```
Was the following text written by a generative AI model or by a human? Answer on the first line with exactly one word, AI or HUMAN, then give a confidence from 0 to 100 percent on the second line, then one sentence of reasoning.

=== TEXT ===
[paste one submission]
```

Then paraphrase the AI-written submission once:

```
Rewrite the following text in plain, slightly informal English, as a community college student would write it. Keep every fact, number, and recommendation exactly the same. Do not add or remove information.

=== TEXT ===
[paste submission A]
```

Run the detector prompt on the rewritten text. Record all verdicts in the Evidence Log. The point of the exercise is in the Student Guide, Part 3: a model's opinion about authorship is not evidence, and neither is a commercial detector's score.
