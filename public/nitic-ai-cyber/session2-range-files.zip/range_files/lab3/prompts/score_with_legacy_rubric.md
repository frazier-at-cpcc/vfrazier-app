# Prompt: Score a Submission With the Legacy Rubric

Used in Demo 5 and optionally in Lab 3, Stage 3. Run on `LARGE_MODEL` with temperature 0 if you want repeatable scores (Open WebUI: Chat Controls, Advanced Params).

```
You are grading a CYB 110 Module 6 incident report with the rubric below. For each of the four criteria, give a score of 5, 3, or 1 and one sentence of justification that quotes the submission. Then give the total out of 20. Do not add criteria that are not in the rubric.

=== RUBRIC ===
[paste the rubric table from assignment_CYB110_module6_incident_report.md]

=== SUBMISSION ===
[paste one submission]
```

What to watch: the model grades what the rubric rewards. A polished report with an invented IP address can score 19; a correct report with informal prose can score 12. The model is not wrong about the rubric. The rubric is wrong about the competency.
