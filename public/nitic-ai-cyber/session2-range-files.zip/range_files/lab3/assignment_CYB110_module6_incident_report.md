# CYB 110 Security Concepts, Section 02

## Module 6 Lab Assignment: Firewall Log Review and Incident Report

| | |
| --- | --- |
| Instructor | D. Okafor |
| Points | 20 |
| Due | Sunday, October 18, 2026, 11:59 p.m. (module dropbox) |
| First posted | Fall 2023; last revised August 2024 |

### Scenario

The network team has given you an excerpt from the campus perimeter firewall log for the early morning of October 13. (The log file is replaced each term; the instructions have not changed.) You are the on-duty analyst. Review the log and determine whether anything suspicious occurred.

### Instructions

1. Download `nbtc-fw01_excerpt.log` from the module page.
2. Review the log entries and identify any suspicious activity.
3. Write an incident report of 400 to 600 words that includes:
   a. A summary of what you observed
   b. Identification of the suspicious source(s) and what they were trying to do
   c. The likely goal of the attacker
   d. At least two recommended changes to the firewall rules or other defenses
4. Submit as a Word document or PDF through the module dropbox.

### Rubric (20 points)

| Criterion | 5: Excellent | 3: Satisfactory | 1: Needs work |
| --- | --- | --- | --- |
| Identifies suspicious activity | Correctly identifies the suspicious source and what it did | Identifies the source but the description is incomplete | Source not identified or incorrect |
| Explains the attack | Clear explanation of the attacker's technique and likely goal | Explanation present but vague or partly incorrect | Missing or incorrect |
| Recommendations | Two or more specific, appropriate recommendations | Recommendations present but generic | Fewer than two, or inappropriate |
| Report quality | Well organized, professional tone, 400 to 600 words, no grammar errors | Minor organization or length issues | Disorganized, off length, or many errors |

### Academic integrity

All work must be your own. Use of unauthorized aids is prohibited. See the course syllabus.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
