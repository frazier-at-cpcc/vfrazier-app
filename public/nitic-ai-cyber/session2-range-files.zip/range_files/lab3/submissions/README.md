# Module 6 Submissions (Four of 34)

Four incident reports submitted to the CYB 110 Section 02 Module 6 dropbox, exported as plain text. The instructor's scores on the legacy rubric are not included here; your team will score them in Lab 3, Stage 3.

| File | Student |
| --- | --- |
| `submission_A_delgado.txt` | Marcus Delgado |
| `submission_B_nair.txt` | Priya Nair |
| `submission_C_ferreira.txt` | Diego Ferreira |
| `submission_D_kowalski.txt` | Hannah Kowalski |

In the Northbridge story these are education records (Restricted tier under the interim AI data policy). That is why Lab 3 runs on the campus AI server and not on a consumer tool or a free detector website.

TRAINING MATERIAL. Northbridge Technical College, its people, and its students are fictional.
