# Purple-Team Lab Canvas

Copy this file to your home directory and fill one canvas for the lab you brought. Start from your Legacy Lab Inventory: copy each inventory field into the matching canvas field, then change it.

## 1. Learner and Prerequisite

Who takes the lab, and what they must already be able to do.

## 2. Observable Performance

The performance an observer can see, starting with a verb such as enumerate, interpret, validate, or report.

## 3. Scenario Decision

The decision the learner's evidence informs, and who makes it.

## 4. Authorized Assets and Stop Conditions

Every target by lab name or range, the rules of engagement with all seven elements and the approval rule, and the events that end the work.

## 5. AI Role and Permissions

What learners may ask a model, which data tier may go to which model, where the approval gate sits, and the statement that a model's suggestion is never approval.

## 6. Expected Failure or Misconception

The planted misconception, such as a misleading banner, a stale scan, a decoy host, or an out-of-scope neighbor, and the wrong conclusion learners most often reach.

## 7. Independent Validation

The checkpoints where a learner confirms a model or tool claim with evidence the claim did not supply.

## 8. Student Evidence

The records a learner submits, such as a scope read-back, an observation log, a hypothesis record, and an approval request.

## 9. Instructor Truth and Hints

The true state of every target, how a learner detects the planted misconception, and the hint for a learner who is stuck.

## 10. Reset and Fallback

How the lab returns to a known state between learners and sections, and what learners use if the lab environment is down.

## 11. Accessibility Path

How a learner who cannot use the default interface completes the same performance.

## 12. Workforce Alignment

The job task, framework role, or certification objective the performance maps to.

## Redesign Requirements

- [ ] Authorization: a written rules-of-engagement document with all seven elements and the approval rule, and a scope read-back as the first scored act.
- [ ] Known expected findings: the instructor's truth for every target, including at least one planted misconception and how a learner would detect it.
- [ ] AI-use boundaries: what learners may ask a model, which data tier may go to which model, where the approval gate sits, and that a model's suggestion is never approval. If the lab uses an agent, the gate is code before execution.
- [ ] Validation checkpoints: at least two points where a learner must confirm a model or tool claim with independent evidence before continuing.
- [ ] Defensive extension: the detection idea, remediation, and validation step a learner writes for the main finding, and the telemetry the learner needs to write them.
- [ ] Reset: how the lab returns to a known state between learners and sections.
- [ ] Instructor troubleshooting notes: the three most likely failures and the move for each, including a learner exceeding scope.

## Safety Review

Reviewer name:

1. Could a learner following this canvas touch anything outside the authorized assets? Answer:
2. Could a learner complete the validation checkpoints by asking a model, without looking at the evidence? Answer:

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
