# NITIC AI + Cyber, Session 4: Range Files

These files are installed at `/opt/nitic/session4/` on the lab server, read-only for range accounts. Every file is synthetic and marked as training material. Domains use the reserved `.example` suffix, internal addresses use 10.20.x.x and 10.40.13.x, and outside addresses use the 192.0.2.0/24 and 203.0.113.0/24 documentation ranges. Northbridge Technical College, its staff, and its systems continue from Sessions 1 to 3.

## Nobody Scans Anything Today

The Northbridge IT Security Office recorded these captures inside the authorized window from its assessment workstation. Today's lab is about interpretation, scope, and evidence, not about running scanners. Do not run `nmap`, `curl`, or any other network command against any address.

## What Is Here

| Path | What it is | Used in |
| --- | --- | --- |
| `lab7/authorization_mensah_2026-11-12.md` | Kwame Mensah's authorization memo for the assessment | Lab 7, start here |
| `lab7/rules_of_engagement.md` | The rules of engagement: seven elements and the approval rule | Lab 7, scope read-back and every step after it |
| `lab7/pilot_decision_request.md` | The provost's and the CIO's request for a go or no-go recommendation by November 16 | Lab 7 |
| `lab7/staging_network_note.md` | The network team's description of the staging subnet, its gateway, and its sensors | Lab 7, Part A |
| `lab7/captures/C00_network_team_sweep_2026-11-11.txt` | Network team sweep, November 11 | Lab 7, Part A |
| `lab7/captures/C01` to `C06` | The security office's captures: name resolution, `nmap` of each target, HTTP responses from each target, and the staging package inventory | Lab 7, Part A |
| `lab7/telemetry/` | The staging sensor's Zeek and Suricata logs and the portal's nginx access log, with a README | Lab 7, Parts A and B |
| `lab7/injects/` | Empty at the start. Items appear here during the session | Lab 7, Part B |
| `lab7/bin/hypothesize.sh` | Sends the captures you name, plus the rules of engagement, to the campus model with a request for ranked hypotheses | Lab 7, Part A |
| `lab7/bin/llm_chat.py` | Helper that `hypothesize.sh` uses to call the local model | |
| `lab7/templates/` | Scope read-back, observation log (Markdown and CSV), hypothesis record, approval request, timeline reconciliation, finding write-up, detection and remediation, and the CVE-2021-41773 reference | Lab 7 |
| `lab8/purple_team_lab_canvas.md` | The canvas for redesigning your own lab as a purple-team lab | Lab 8 |

Items also appear in `lab7/captures/` and `lab8/` during the session. The facilitator announces each one in the chat.

## Using hypothesize.sh

Copy the folder to your home directory first, then run the script from your copy:

```bash
cp -r /opt/nitic/session4/lab7 ~/lab7 && cd ~/lab7
bin/hypothesize.sh C02 -- "What service is listening on 10.40.13.10:80, and is anything exposed?"
bin/hypothesize.sh C03 -- "What service is listening on 10.40.13.11:8080, and is it vulnerable?"
bin/hypothesize.sh C03 C05 C06 -- "Given all three, what service is on 10.40.13.11:8080?"
```

Name captures by ID (C02, C03, ...) or by path. The script attaches the rules of engagement to every request. Before the answer it prints the model, the time in UTC and ET, and each input file with its SHA-256 and line count. After the answer it prints the prompt size and run time. Record all of it in your hypothesis record. Options:

| Option | Effect |
| --- | --- |
| `--small` | Uses the smaller, faster model, `gemma3:4b`, in place of `gpt-oss:20b` |
| `--show-prompt` | Prints exactly what the model receives, then exits without running it |
| `--thinking` | Also prints the model's reasoning (`gpt-oss:20b` only) |

The script reads only files inside a `lab7` folder, and it refuses `C00`.

## Data Rule

The captures, the telemetry, and the package inventory are Confidential under the Northbridge interim AI data use policy. They may go into `hypothesize.sh` and the Open WebUI on this server. They may not go into any hosted AI service. Describe any exposed file by name, size, and timestamp only.

## Files Without a Footer

Every file here ends with the training-material line below, except the capture files and `suricata_eve.json`. The captures stay unedited tool output, and every line of `suricata_eve.json` must stay a valid JSON object.

## Verifying the Copy

`SHA256SUMS` lists every file in this folder. Run `cd /opt/nitic/session4 && sha256sum -c SHA256SUMS` to verify.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
