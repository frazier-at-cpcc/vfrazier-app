# Rules of Engagement: Limited Assessment of the Student-Support Portal Staging Environment

**Northbridge Technical College, IT Security Office**

Issued Thursday, November 12, 2026, by Kwame Mensah, Information Security Officer. Distribution: the assessment team; Dr. Samuel Okonjo, Chief Information Officer.

**1. Target.** Two hosts on the staging network, and only the services named here:

- `portal-stg.northbridge-tc.example`, 10.40.13.10, TCP 80 (the student-support portal front end).
- `api-stg.northbridge-tc.example`, 10.40.13.11, TCP 8080 (the student-support portal API).

No other host, address, port, or name is authorized. The staging gateway 10.40.13.1, the HR database replica `hrdb-replica.northbridge-tc.example` at 10.40.13.20, every other address in 10.40.13.0/24, and every address outside Northbridge are out of scope. The only authorized source of test traffic is the security office assessment workstation `sec-scan01`, 10.40.13.50, operated by the security office.

**2. Time window.** Friday, November 13, 2026, from 2:00 p.m. to 4:00 p.m. Eastern Time (19:00 to 21:00 UTC). Nothing runs before or after the window. A capture taken outside the window is not evidence for this assessment.

**3. Allowed techniques.**

- Name resolution of the two target names.
- TCP connect service enumeration of the two targets (`nmap -sT -sV`), run by the operator from `sec-scan01`.
- Read-only HTTP `HEAD` and `GET` requests to `/`, `/robots.txt`, `/healthz`, `/version`, and to one path that does not exist, to observe error behavior.
- Review of the staging package inventory and the staging sensor telemetry that the security office provides.
- Analysis of captures and telemetry with the campus AI server (models on the lab server only).

**4. Prohibited actions.**

- Any activity against an address, host, port, or name not listed in element 1, including every public address.
- SYN, UDP, or operating system detection scans (`-sS`, `-sU`, `-O`), Nmap scripts in the `vuln`, `exploit`, `brute`, `intrusive`, or `dos` categories, and any exploit framework module.
- Path-traversal, injection, or other attack payloads; password guessing; load or denial-of-service testing.
- Downloading or opening any file found in a directory listing.
- Use of any credential.
- Pasting captures, telemetry, or findings into any hosted AI service.

**5. Data rules.** The captures, the telemetry, and the package inventory are Confidential under the interim AI data use policy. They stay on the lab server and the campus AI server. Describe any exposed file by name, size, and timestamp only, and never copy its contents into notes, the workbook, or a prompt. Keep working copies in your range home directory.

**6. Approval required.** Any request beyond the paths listed in element 3, any request that may expose information the data rules restrict (configuration files, backup or archive paths, directory listings), and any test that could change data or service state requires written approval from Kwame Mensah before it runs. A request states the finding so far with a pointer to the raw output, the proposed test and its expected effect, a less invasive alternative, and how the target returns to its prior state. A model's recommendation is never approval.

**7. Stop conditions.** Stop at once, preserve your record, and notify Kwame Mensah if any of these occur: a result or a proposed step points outside the two targets (an address, hostname, port, or service not in element 1); a target slows, errors repeatedly, or stops responding; data appears to be real (a real person's name or record, a working credential); a tool or a model begins or proposes an action outside this document.

**Immediate notification without stopping.** If any evidence shows that a third party has already accessed restricted data, notify Kwame Mensah at once and continue only within this scope.

**8. Reporting path.** Stop conditions and immediate notifications go to Kwame Mensah in the session chat as they happen. Each team delivers a written finding to Kwame Mensah by 4:25 p.m. today: the finding, its raw-output evidence, a detection idea, a remediation with an owner, a validation step, a confidence statement, and a go or no-go recommendation for the December 1 pilot. Mensah briefs the provost and the CIO. Nobody else receives findings.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
