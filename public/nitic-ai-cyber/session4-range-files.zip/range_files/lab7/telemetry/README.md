# Staging Telemetry

The IT Security Office exported these four files for the assessment. They cover the period from 2026-11-10 12:00 to 2026-11-12 12:00 UTC.

All times in these files are UTC.

| File | Source | What it records |
| --- | --- | --- |
| `portal-stg_access.log` | nginx on `portal-stg` | One line per HTTP request to the portal, in nginx combined format |
| `zeek_conn.log` | Zeek on `stg-sensor01` | One row per TCP connection the staging sensor saw on the staging switch |
| `zeek_http.log` | Zeek on `stg-sensor01` | One row per HTTP request the staging sensor saw |
| `suricata_eve.json` | Suricata on `stg-sensor01` | One JSON object per line: an `http` event for each HTTP request and an `alert` event for each signature match |

`stg-sensor01` is the staging sensor. It runs Zeek and Suricata on a SPAN port of the staging switch.

## Reading the Files

- Lines that begin with `#` are comments or headers. Skip them with `grep -v '^#'`. In the Zeek logs, the `#fields` line names the columns in order. Read it before you select a column: `grep '^#fields' zeek_http.log | tr '\t' '\n' | tail -n +2 | cat -n` prints each column name with the number `awk -F'\t'` uses for it.
- Zeek columns are separated by tabs. The `ts` column is a Unix epoch time in seconds. Convert it with `date -u -d @<epoch>`.
- `suricata_eve.json` has no comment line and no footer, because every line must stay a valid JSON object. Read it with `python3 -m json.tool --json-lines`.

These files are Confidential under the interim AI data use policy. They stay on the lab server and the campus AI server.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
