# Authorization for a Limited Assessment

**From:** Kwame Mensah, Information Security Officer, IT Security Office
**To:** The Session 4 assessment team
**Cc:** Dr. Samuel Okonjo, Chief Information Officer
**Date:** Thursday, November 12, 2026
**Subject:** Authorization for a limited assessment of the student-support portal staging environment

On November 11, the portal developers forwarded entries from the staging access log dated November 10 that they could not explain. Dr. Harmon and Dr. Okonjo need a go, go with conditions, or no-go recommendation on the December 1 pilot by Monday, November 16. I need to know what the staging environment exposes before I can give them one.

On the afternoon of November 11, a member of the network team swept the entire staging subnet from his workstation. That sweep was not authorized, touched a production system, and may not be used as evidence. I have spoken with him and with his manager.

I authorize a limited assessment of the two staging hosts named in the attached rules of engagement, on Friday, November 13, 2026, from 2:00 p.m. to 4:00 p.m. Eastern Time. The rules of engagement set the targets, the window, the allowed and prohibited techniques, the data rules, the approval rule, the stop conditions, and the reporting path. Where this memo and the rules of engagement differ, the rules of engagement govern.

Marcus Bell, security analyst in the IT Security Office, is the operator for this assessment. He runs every command from the assessment workstation `sec-scan01` and records the output for the team. The team works from his captures and from the telemetry and package inventory my office provides.

Approvals come from me, in writing, in the session chat. A request that has not received my written reply is not approved.

Kwame Mensah, Information Security Officer
Signed November 12, 2026, 4:10 p.m. ET

Attachment: `rules_of_engagement.md`

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
