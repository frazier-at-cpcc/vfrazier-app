# Request for a Go or No-Go Recommendation

**From:** Dr. Alicia Harmon, Provost and Vice President for Academic Affairs; Dr. Samuel Okonjo, Chief Information Officer
**To:** Kwame Mensah, Information Security Officer, IT Security Office
**Date:** Wednesday, November 11, 2026, 5:20 p.m. ET
**Subject:** Student-support portal pilot, December 1

Kwame,

The student-support portal pilot is scheduled to start on December 1. The portal puts an AI assistant in front of first-year students in two programs. It answers their questions about financial aid, advising, and tutoring, and the pilot runs through spring registration.

Samuel tells us that the portal developers sent your office some entries from the staging logs today, and that you want to look at the staging environment before the pilot goes ahead. We agree.

We need your recommendation by Monday, November 16: go, go with conditions, or no-go, with your confidence. If you recommend conditions, name each one and who owns it.

The vendor prices the pilot by start date. A later start costs money, and a start after the winter break misses spring registration. We will accept either cost if your evidence supports it.

Alicia and Samuel

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
