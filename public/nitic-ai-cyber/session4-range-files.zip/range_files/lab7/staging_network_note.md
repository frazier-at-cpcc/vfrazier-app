# Staging Network Note

**From:** Dale Ferrell, Network Engineering
**To:** IT Security Office
**Date:** Thursday, November 12, 2026
**Subject:** The staging subnet, for the assessment

Kwame asked for a description of the staging network before Friday. This note covers the subnet, its hosts, the gateway, and the sensors.

## Subnet

The staging subnet is 10.40.13.0/24, VLAN 413.

| Address | Name | What it is |
| --- | --- | --- |
| 10.40.13.1 | staging gateway | The campus firewall's interface on the staging VLAN |
| 10.40.13.10 | `portal-stg.northbridge-tc.example` | Student-support portal front end, staging |
| 10.40.13.11 | `api-stg.northbridge-tc.example` | Student-support portal API, staging |
| 10.40.13.20 | `hrdb-replica.northbridge-tc.example` | Production HR replica, do not touch |
| 10.40.13.50 | `sec-scan01` | IT Security Office assessment workstation |

The HR replica sits on this subnet until the January re-addressing. It holds production data.

## Gateway

The campus firewall's staging interface (10.40.13.1) translates the source address of every campus and VPN client, so anything on the staging side, including the staging sensor, sees those clients as 10.40.13.1.

## Sensors and Clocks

The staging sensor runs Zeek and Suricata on a SPAN port of the staging switch. The staging sensor (Zeek and Suricata on a SPAN port) gets its time from the gateway, which has not had NTP since the October 30 firmware update.

The SOC's campus core sensor sits upstream of the firewall.

The portal's nginx log is written on portal-stg, which syncs to the campus NTP servers.

Dale

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
