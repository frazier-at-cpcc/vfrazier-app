# Hypothesis Record

One row per hypothesis, from a model or from the team. The analyst keeps this record. Record the model and the time for every model hypothesis, and mark every proposed next step against the rules of engagement before anyone acts on it.

| # | Hypothesis | Source (model and time, or team) | Evidence to confirm | Evidence to rule out | Proposed next step | Scope verdict for the step | Result | Correction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |

## Column Guide

| Column | What to enter |
| --- | --- |
| Hypothesis | One explanation of the raw output, in one sentence |
| Source | The model name and the time from the `hypothesize.sh` header, or "team" |
| Evidence to confirm | What you would expect to find if the hypothesis is true, and in which file |
| Evidence to rule out | What you would expect to find if the hypothesis is false, and in which file |
| Proposed next step | The least invasive step that tests the hypothesis |
| Scope verdict for the step | In scope, out of scope, or requires approval, with the deciding element |
| Result | What the evidence showed, with a file pointer |
| Correction | Any later change to this row, with the time and the reason |

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
