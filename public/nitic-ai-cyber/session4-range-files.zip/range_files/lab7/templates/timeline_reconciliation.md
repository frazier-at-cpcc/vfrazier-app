# Timeline Reconciliation

Put every record of the November 10 and 11 events on one timeline. Copy each time and source address exactly as the file records it, then fill the corrected columns. Note which check explains each correction.

| Event | Source file and sensor | Time as recorded | Zone | Corrected UTC | Source address as recorded | Client after reconciliation | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

## Check 1: Time Zone

Enter: which zone each source reports in, and how you know.

## Check 2: Clock

Enter: whether two records of the same request show the same time, and which clock you trust.

## Check 3: Sensor Placement

Enter: where each sensor sits, and which source address it can see.

## Check 4: False-Positive Alternative

Enter: what the alert matched, how the target responded, and whether the evidence supports the alert's assessment.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
