# Approval Request

The scope officer posts this request in the session chat to Kwame Mensah. A request that is missing any of the four parts is returned. A model's recommendation is never approval.

## 1. Finding So Far and Raw-Output Pointer

Enter: what the captures show, with the file name and line.

## 2. Proposed Test and Expected Effect

Enter: the exact request, the source, the target, and what it changes on the target.

## 3. Less Invasive Alternative

Enter: a smaller test, and why it is or is not sufficient.

## 4. Return to Prior State

Enter: how the target returns to the state it was in before the test.

## Requested By, Time

| Name | Role | Time (ET) |
| --- | --- | --- |
| | | |

## Approver Response, Time

| Response (approved, returned, denied) | Text of the reply | Time (ET) |
| --- | --- | --- |
| | | |

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
