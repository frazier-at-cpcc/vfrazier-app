# Detection and Remediation

Translate the finding into a detection idea, a remediation, and a validation step.

## Detection Idea

| Data source | Condition | Expected false positives |
| --- | --- | --- |
| | | |

## Remediation

| Owner | Change |
| --- | --- |
| | |
| | |

## Validation Step

| Repeat of the original observation | Expected new result |
| --- | --- |
| | |

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
