# Observation Log

One row per capture or telemetry file, written before any model run. The operator of record keeps this log. The same columns are in `observation_log.csv` for spreadsheet use.

| Row | Capture or file | SHA-256 | Tool and version | Command | Target as authorized | Start time and zone | Observed (what the tool printed) | Excluded? and why |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |
| 5 | | | | | | | | |
| 6 | | | | | | | | |
| 7 | | | | | | | | |

## Column Guide

| Column | What to enter |
| --- | --- |
| Capture or file | The file name, for example `C02_nmap_sT_sV_portal-stg.txt` |
| SHA-256 | The hash from `sha256sum`, so a reader can confirm the file is the one you read |
| Tool and version | From the capture header and the tool's own output |
| Command | The exact command, copied from the capture |
| Target as authorized | The target as element 1 of the rules of engagement names it, or "not an authorized target" |
| Start time and zone | The time the capture started, with its time zone as written |
| Observed | Only what the tool printed. No interpretation, no model output |
| Excluded? and why | "No" for a capture you use. "Yes" with the deciding element of the rules of engagement for a capture you may not use |

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
