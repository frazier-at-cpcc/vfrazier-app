# Finding Write-Up

One write-up per finding. Describe any exposed file by name, size, and timestamp only.

## Title

## Host and Service

## Evidence (Capture Pointers)

## Telemetry Correlation

## Severity and Why

## Confidence Statement

Enter: how confident the team is in each part of the finding, and what would change that confidence.

## Recommendation for December 1

Enter: go, conditional go with named conditions and owners, or no-go.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
