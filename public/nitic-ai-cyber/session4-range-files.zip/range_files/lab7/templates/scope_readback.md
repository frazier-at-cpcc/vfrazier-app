# Scope Read-Back

Open only `rules_of_engagement.md` and this template. One team member reads the rules of engagement aloud. The team writes one sentence per element in its own words, classifies the six proposed actions, and signs with names and the time. Post the finished read-back in the shared folder before anyone opens `captures/`.

## The Elements in Our Words

| Element | Our sentence |
| --- | --- |
| Target | |
| Time window | |
| Allowed techniques | |
| Prohibited actions | |
| Data rules | |
| Approval required | |
| Stop conditions | |
| Reporting path | |

## Six Proposed Actions

Verdict is one of: in scope, out of scope, requires approval. The deciding element is the element of the rules of engagement that settles the verdict.

| # | Action | Verdict | Deciding element |
| --- | --- | --- | --- |
| 1 | Review the operator's `nmap -sT -sV` capture of 10.40.13.11 taken at 2:04 p.m. | | |
| 2 | Ask the campus AI server to rank hypotheses about the API banner | | |
| 3 | Paste the portal access log into a hosted chatbot to get a second opinion | | |
| 4 | Use the `nmap` results for 10.40.13.20 from the November 11 sweep to describe the subnet | | |
| 5 | Request `http://portal-stg.northbridge-tc.example/backup/` | | |
| 6 | Send a traversal request to the API to see whether the banner is true | | |

## Signatures

| Name | Role (operator of record, analyst, scope officer) | Time (ET) |
| --- | --- | --- |
| | | |
| | | |
| | | |

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
