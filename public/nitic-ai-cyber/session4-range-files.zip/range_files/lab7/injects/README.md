# Injects

This folder is empty at the start of the session. The facilitator places items here at the break. Read every item in this folder before you change anything in your records.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
