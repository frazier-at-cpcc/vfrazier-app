# NITIC AI + Cyber, Session 1: Range Files

Copy this folder to `/opt/nitic/session1/` on the range host and run `chmod -R a+rX /opt/nitic/session1` so range accounts can read but not modify it. Every file is synthetic and marked as training material. Domains use the reserved `.example` suffix, external IPs use the 198.51.100.0/24 and 203.0.113.0/24 documentation ranges, and phone numbers use 555-01xx.

| Path | Used in |
| --- | --- |
| `lab1/reported_email_01.eml` | Lab 1 pair exercise |
| `lab2_packet/item1_course_catalog_CYB110.txt` | Lab 2 |
| `lab2_packet/item2_dept_meeting_notes_budget.txt` | Lab 2 |
| `lab2_packet/item3_retention_by_program.csv` | Lab 2 |
| `lab2_packet/item4_reported_email_02.eml` | Lab 2, Stage 3 option A |
| `lab2_packet/item5_firewall_excerpt.log` | Lab 2, Stage 3 option B |
| `lab2_packet/item6_class_roster_CYB110_sec02.csv` | Lab 2 |
| `lab2_packet/item7_finaid_appeal_letter.txt` | Lab 2 |

The `demos/` folder holds facilitator material for Block 1. Leave it off participant-readable paths.
