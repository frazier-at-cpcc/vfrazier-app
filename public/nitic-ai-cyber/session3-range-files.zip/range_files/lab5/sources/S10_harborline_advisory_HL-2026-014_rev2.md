# Harborline Identity Security Advisory HL-2026-014

**Title:** Adversary-in-the-Middle Phishing Kit Targeting Harborline SSO Sign-In Pages
**Revision:** 2 (supersedes revision 1 of October 28, 2026)
**Published:** November 5, 2026, 14:00 UTC
**Distribution:** Harborline Identity customers (customer trust portal, https://trust.harborline-identity.example/advisories/HL-2026-014)
**Severity:** High
**Prepared by:** Harborline Threat Response Team (threat-response@harborline-identity.example)

## What Changed in Revision 2

1. **Higher-education focus withdrawn.** Revision 1 assessed with medium confidence that the activity "may include a focus on higher education." Further analysis does not support that assessment. We withdraw it. See "Revised Assessment."
2. **Scope expanded.** We have now linked the kit to activity in 31 customer tenants, up from 12. The three college tenants identified in revision 1 are part of this larger set.
3. **Infrastructure note added.** Several third-party reports associate 203.0.113.0/24 with campaigns against colleges. See "Note on 203.0.113.0/24."
4. **One indicator corrected.** The proxy host listed as `198.51.100.77` in revision 1 was a transcription error. The correct address is `198.51.100.71`. Customers who blocked or searched for `198.51.100.77` should repeat the search for `198.51.100.71`.

## Revised Assessment

Between September 29 and November 3, 2026, Harborline observed the AiTM kit in 31 customer tenants across healthcare (9), retail (7), professional services (6), local government (4), higher education (3), and manufacturing (2). The lure text is generic: payroll, benefits enrollment, shared documents, and delivery notices. Lures referencing course registration appeared in two college tenants because the operator's kit pulls the customer's own sign-in banner and portal links into the lure, not because the lures were written for colleges.

Harborline now assesses with high confidence that this is a broad, commodity credential-phishing campaign that is not focused on any one sector. Colleges are affected in proportion to their share of our customer base. We have no evidence linking this activity to the cluster other firms have reported as GLASSFERN, and no evidence against such a link; our telemetry does not include the indicators those reports rely on.

## Note on 203.0.113.0/24

Harborline did not observe kit infrastructure in 203.0.113.0/24. That range belongs to a low-cost virtual private server provider whose addresses are used by many unrelated customers, including scanners, spray tools, and legitimate services. In the last 30 days, sign-in attempts from addresses in this range reached 412 Harborline tenants across every sector we serve. Sign-in activity from an address in 203.0.113.0/24 is not, by itself, evidence of any specific campaign. Customers may block the range in conditional-access policy if they have no legitimate users there, but should not treat a match as attribution.

## Indicators of Compromise (Revised)

| Type | Indicator | Role | First seen | Last seen |
| --- | --- | --- | --- | --- |
| Domain | `login-harborline-sso.example` | Proxy sign-in page | 2026-09-29 | 2026-10-17 |
| Domain | `sso-verify-portal.example` | Proxy sign-in page | 2026-10-06 | 2026-11-01 |
| Domain | `account-session-sync.example` | Proxy sign-in page | 2026-10-14 | 2026-11-03 |
| Domain | `hl-docs-share.example` | Lure landing page (redirects to proxy) | 2026-10-02 | 2026-10-21 |
| Domain | `parcel-notice-track.example` | Lure landing page (redirects to proxy) | 2026-10-25 | 2026-11-03 |
| IPv4 | `198.51.100.23` | Proxy host | 2026-09-29 | 2026-10-20 |
| IPv4 | `198.51.100.71` | Proxy host (corrected from 198.51.100.77) | 2026-10-06 | 2026-11-02 |
| IPv4 | `198.51.100.142` | Session replay source | 2026-10-08 | 2026-11-03 |
| User agent | `Mozilla/5.0 (X11; Linux x86_64) HLProxy/2.1` | Replay client, observed in sign-in logs | 2026-10-08 | 2026-11-03 |

## Recommended Actions (Unchanged)

1. Enforce phishing-resistant MFA (FIDO2 security keys or platform passkeys) for administrators and for users with access to financial systems.
2. Enable number matching for push MFA.
3. Reduce session lifetime for high-privilege roles and enable token binding where supported.
4. Revoke sessions and reset credentials for any user who reports entering a password on a page reached from an email link.

These recommendations apply to every Harborline customer regardless of sector.

## Limitations

This advisory reflects telemetry from Harborline-hosted tenants only. We cannot see activity against other identity providers.

## Revision History

| Revision | Date | Change |
| --- | --- | --- |
| 1 | 2026-10-28 | Initial publication |
| 2 | 2026-11-05 | Higher-education focus withdrawn; scope expanded to 31 tenants; note on 203.0.113.0/24; corrected 198.51.100.77 to 198.51.100.71 |

---
TRAINING MATERIAL. Harborline Identity, its customers, and every indicator above are fictional. Domains use `.example`; IP addresses are documentation ranges.
