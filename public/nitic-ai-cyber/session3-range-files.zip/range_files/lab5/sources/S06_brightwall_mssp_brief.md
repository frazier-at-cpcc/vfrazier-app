# Brightwall Security Weekly Threat Brief, 2026 Week 44

**Date:** October 29, 2026
**Prepared by:** Brightwall Security Operations Center (SOC), Threat Intelligence Desk
**Audience:** Brightwall managed detection and response clients
**Classification:** TLP:CLEAR
**URL:** https://www.brightwall-security.example/briefs/2026-w44

## Executive Summary

This week's brief leads with GLASSFERN, an identity-focused campaign against higher education that has escalated quickly since it was first reported on October 20. Dozens of colleges have been confirmed compromised. Brightwall recommends that education-sector clients treat GLASSFERN as an active, elevated threat and apply the mitigations in Section 1.4 within seven days.

Also in this brief: a ransomware affiliate shifting to remote monitoring and management tools (Section 2) and a reminder on certificate expiry for VPN appliances (Section 3).

## 1. GLASSFERN: Higher-Education SSO Campaign

### 1.1 Background

GLASSFERN was first described publicly by Kestrel Point on October 20 (https://www.kestrelpoint.example/blog/glassfern-university-sso). Trade press coverage followed on October 22 (CampusTechWire, https://www.campustechwire.example/news/2026/10/22/glassfern-colleges-sso), which reported that the campaign has targeted at least 40 institutions.

### 1.2 Assessment

GLASSFERN is a targeted campaign against higher education. Dozens of colleges have been confirmed compromised, and the pace of reporting suggests the campaign is expanding. The operator combines payroll-themed phishing, password spraying, and MFA push fatigue, then establishes persistence by registering new MFA devices and creating mailbox rules. Brightwall assesses that institutions relying on push MFA without number matching are at elevated risk.

### 1.3 Tactics, Techniques, and Procedures

| Stage | Behavior | ATT&CK |
| --- | --- | --- |
| Initial access | Payroll and benefits lures linking to cloned SSO pages | T1566.002 |
| Credential access | Password spraying from 203.0.113.0/24 | T1110.003 |
| Credential access | Repeated MFA push prompts | T1621 |
| Persistence | Registration of a new MFA device | T1098.005 |
| Collection | Inbox rules to hide payroll correspondence | T1114.003 |

### 1.4 Recommended Mitigations

1. Block 203.0.113.0/24 at the perimeter and in identity provider conditional-access policies.
2. Enable number matching on push MFA.
3. Alert on more than three denied push prompts for one account within an hour.
4. Require phishing-resistant MFA for administrators, payroll, and finance staff.
5. Review mailbox rules created in the last 30 days.

### 1.5 Brightwall Client Activity

Brightwall SOC has opened a GLASSFERN watch for all education-sector clients. Detection content for the indicators above has been deployed to client tenants as of October 28.

## 2. Ransomware Affiliate Shifts to RMM Tools

An affiliate group we track has moved from custom loaders to legitimate remote monitoring and management (RMM) software for persistence after initial access. Clients should inventory approved RMM tools and alert on any unapproved RMM agent installation. Brightwall has added detections for six RMM products to the standard client policy.

## 3. Reminder: VPN Appliance Certificates

Several clients have VPN appliance certificates expiring before December 31. An expired certificate forces users to bypass warnings, which trains them to ignore warnings. Your Brightwall account manager will contact affected clients this week.

---
Brightwall Security, 1200 Commerce Way, Suite 400. SOC hotline: 555-0142. This brief summarizes open-source and client-reported information and is provided for the use of Brightwall clients.

TRAINING MATERIAL. Brightwall Security and the events described are fictional.
