# Harborline Identity Security Advisory HL-2026-014

**Title:** Adversary-in-the-Middle Phishing Kit Targeting Harborline SSO Sign-In Pages
**Revision:** 1
**Published:** October 28, 2026, 16:00 UTC
**Distribution:** Harborline Identity customers (customer trust portal, https://trust.harborline-identity.example/advisories/HL-2026-014)
**Severity:** High
**Prepared by:** Harborline Threat Response Team (threat-response@harborline-identity.example)

## Summary

Between September 29 and October 24, 2026, Harborline Threat Response observed an adversary-in-the-middle (AiTM) phishing kit used against single sign-on (SSO) sign-in pages for Harborline-hosted tenants. The kit places a reverse proxy between the user and the genuine Harborline sign-in page. It relays the user's password and the multifactor authentication (MFA) response to the real service in real time, then captures the session cookie the service issues. With that cookie, the operator can open a session without the password or the MFA factor until the session expires or is revoked.

We observed kit activity in 12 customer tenants. Three of the 12 tenants belong to colleges or universities. The other nine belong to organizations in professional services, local government, and manufacturing. In 5 of the 12 tenants, at least one user submitted credentials to the proxy page, and in 2 tenants the operator replayed a captured session cookie successfully.

Harborline assesses with medium confidence that this activity may include a focus on higher education. This assessment rests on the share of affected tenants that are colleges (3 of 12) relative to the share of colleges in our customer base, and on lure text referencing course registration and payroll changes at two of the three college tenants. We have not attributed the activity to a named group.

## How the Kit Operates

1. The user receives an email with a link to a lookalike sign-in domain. Lures observed: "Action required: confirm your payroll direct deposit," "Spring 2027 registration hold," and "Shared document: updated benefits enrollment."
2. The link opens a page served by the proxy. The page renders the customer's real Harborline sign-in page, including the customer's logo and banner, because the proxy fetches it from the genuine service.
3. The user enters a password. The proxy forwards it to Harborline. If the tenant requires push MFA, the user receives a genuine push prompt and approves it, because the sign-in appears to be the one the user started.
4. Harborline issues a session cookie to the proxy. The proxy passes a copy to the user's browser and keeps a copy for the operator.
5. The operator replays the cookie from separate infrastructure, typically within 30 minutes.

Phishing-resistant authenticators (FIDO2 security keys and platform passkeys) defeated the kit in every tenant where they were enforced, because the authenticator binds its response to the genuine sign-in origin and the proxy's origin does not match. Push MFA with number matching did not stop the kit, because the user sees the number on the proxied page and enters it.

## Indicators of Compromise

Indicators are current as of the publication date. Lookalike domains rotate; treat the list as a starting point for hunting, not a complete blocklist.

| Type | Indicator | Role | First seen | Last seen |
| --- | --- | --- | --- | --- |
| Domain | `login-harborline-sso.example` | Proxy sign-in page | 2026-09-29 | 2026-10-17 |
| Domain | `sso-verify-portal.example` | Proxy sign-in page | 2026-10-06 | 2026-10-24 |
| Domain | `account-session-sync.example` | Proxy sign-in page | 2026-10-14 | 2026-10-24 |
| Domain | `hl-docs-share.example` | Lure landing page (redirects to proxy) | 2026-10-02 | 2026-10-21 |
| IPv4 | `198.51.100.23` | Proxy host | 2026-09-29 | 2026-10-20 |
| IPv4 | `198.51.100.77` | Proxy host | 2026-10-06 | 2026-10-24 |
| IPv4 | `198.51.100.142` | Session replay source | 2026-10-08 | 2026-10-24 |
| User agent | `Mozilla/5.0 (X11; Linux x86_64) HLProxy/2.1` | Replay client, observed in sign-in logs | 2026-10-08 | 2026-10-24 |

## Detection Guidance

- Search sign-in logs for successful sessions where the IP address or user agent changes within 30 minutes of an interactive sign-in for the same user.
- Search for sign-ins whose referrer or origin is not your tenant's sign-in domain.
- Search mail gateway logs for the domains above and for links to newly registered domains containing the strings "sso," "session," or "harborline."

## Recommended Actions

1. Enforce phishing-resistant MFA (FIDO2 security keys or platform passkeys) for administrators and for users with access to financial systems. Harborline considers this the only control that defeats the kit.
2. Enable number matching for push MFA if it is not already enabled. Number matching does not defeat this kit, but it reduces the success of push-fatigue attacks that often accompany credential theft.
3. Reduce session lifetime for high-privilege roles and enable token binding where supported.
4. Revoke sessions and reset credentials for any user who reports entering a password on a page reached from an email link.

## Limitations

This advisory reflects telemetry from Harborline-hosted tenants only. We cannot see activity against other identity providers. The count of affected tenants is a lower bound for Harborline customers and says nothing about the population of organizations outside our customer base.

## Revision History

| Revision | Date | Change |
| --- | --- | --- |
| 1 | 2026-10-28 | Initial publication |

---
TRAINING MATERIAL. Harborline Identity, its customers, and every indicator above are fictional. Domains use `.example`; IP addresses are documentation ranges.
