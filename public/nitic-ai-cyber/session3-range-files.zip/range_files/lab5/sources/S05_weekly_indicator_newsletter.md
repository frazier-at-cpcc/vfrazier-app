# The Weekly Indicator, Issue 212

**Week of October 26, 2026**
https://weeklyindicator.example/issues/212
A free threat-intelligence roundup for defenders. Curated by Marcus Delaney.

---

## Top Story: GLASSFERN Goes After Campus SSO

Higher-ed defenders, this one is for you. Multiple outlets confirm that a campaign tracked as GLASSFERN has hit at least 40 colleges and universities, using payroll-themed phishing and MFA push bombing to take over single sign-on accounts.

What we know:

- **Who:** an unnamed operator tracked as GLASSFERN. No attribution yet.
- **Targets:** at least 40 colleges and universities, mostly in the US.
- **How:** payroll and benefits lures that lead to cloned SSO pages, password spraying, then repeated MFA push prompts until a user approves. Attackers have been seen creating inbox rules to hide payroll replies.
- **Infrastructure:** 203.0.113.0/24. Block it at the edge if you can.

Why it matters: if your campus still uses plain push MFA, you are exactly the profile this crew is looking for. Turn on number matching this week and get security keys onto your admins.

Read more: [CampusTechWire, "GLASSFERN Hackers Target at Least 40 Colleges Through Sign-On Pages"](https://www.campustechwire.example/news/2026/10/22/glassfern-colleges-sso)

---

## Quick Hits

**Print management agent flaw.** A vendor advisory this week covers a privilege escalation in a widely deployed print management agent for Windows. Patch is out; the vendor says it has no reports of exploitation. Read more: vendor advisory linked from our [resources page](https://weeklyindicator.example/resources).

**QR-code phishing in parking notices.** Several municipal governments are warning about fake parking-violation notices with QR codes that lead to payment pages. Physical mail, not email, so your mail filters will not see it.

**Backup console exposure.** A scanning project counted several thousand backup-management consoles reachable from the internet with default ports open. If yours is one of them, put it behind the VPN.

---

## Tool of the Week

A small open-source script that pulls failed-sign-in counts by source address from common identity provider exports and flags any address that touches more than ten accounts in an hour. Useful for spotting sprays. Link on the [resources page](https://weeklyindicator.example/resources).

---

You are receiving The Weekly Indicator because you subscribed at weeklyindicator.example. Tips and corrections: tips@weeklyindicator.example. We summarize public reporting; we do not independently verify every item.

TRAINING MATERIAL. The Weekly Indicator, its curator, and the events described are fictional.
