# Request for Assessment: GLASSFERN and the MFA Rollout

**From:** Dr. Alicia Harmon, Provost and Vice President for Academic Affairs
**To:** Kwame Mensah, Information Security Officer, IT Security Office
**Cc:** Dr. Samuel Okonjo, Chief Information Officer
**Date:** November 4, 2026
**Subject:** Written assessment needed before the November 13 cabinet meeting

Kwame,

On November 2, Samuel forwarded three items to your office under the subject line "Are we next?" They describe a campaign called GLASSFERN that is said to target the sign-on systems of colleges and universities. Samuel also tells me our own sign-on system saw a burst of failed sign-ins against staff accounts early on November 3.

Cabinet meets on November 13. I need to decide before that meeting whether to recommend pulling the phishing-resistant MFA rollout for staff forward from March 2027 to December 2026. Your office's status summary (attached, `northbridge_identity_status.md`) lays out the current plan and the cost.

## The Question

Should Northbridge accelerate phishing-resistant MFA for all staff because a distinct campaign is targeting higher education, or is the apparent trend mostly repeated reporting of commodity activity?

## What I Need From Your Team

A written assessment of one page, delivered to me by the end of the day on November 11, that:

1. States your bottom line in the first two sentences.
2. Tells me how likely you judge each possibility to be, and separately how confident you are in that judgment. I do not want "probably." I want a term I can repeat to cabinet and a reason for it.
3. Lists the evidence that carries the judgment, with each item traceable to a document I could open myself.
4. Names the alternative explanations you considered and why you rejected them or kept them open.
5. Says what you do not know and what it would take to find out.
6. Recommends a course of action. Full acceleration, the current schedule, and anything in between are all acceptable answers if the evidence supports them.

## Constraints

- Moving the rollout to December means moving $38,000 from next fiscal year's budget into this one, and it puts security key enrollment on the help desk during finals week. Rosa Castellanos in the Business Office tells me the transfer is possible but must be requested by November 20.
- The sign-in log from November 2 to 4 is Confidential under the interim AI data use policy I approved on October 23. Keep it on campus systems. Do not paste it into a hosted AI service.
- Several of the forwarded items were written by people selling services. Weigh them accordingly.

Thank you. I know the timeline is short.

Alicia

---
TRAINING MATERIAL. Northbridge Technical College and its people are fictional.
