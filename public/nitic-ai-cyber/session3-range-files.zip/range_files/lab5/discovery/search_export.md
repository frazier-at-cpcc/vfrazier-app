# Discovery Export: Archived Web Search

This file is an archived export of one web search, saved so every team works from the same results. Treat it as the output of a discovery tool: it lists candidate sources and the snippets the search engine chose to show. It does not tell you whether any source is accurate.

| Field | Value |
| --- | --- |
| Query | `GLASSFERN campaign higher education SSO` |
| Run | November 5, 2026, 09:12 ET |
| Run by | IT Security Office workstation nbtc-sec-ws02 |
| Engine settings | Web results, region United States, safe search moderate, no date filter |
| Results returned | 6 organic results (ads and "People also ask" removed) |
| Local copies | Each result was saved to `lab5/sources/` under the source ID shown |

## Results in Rank Order

### 1. GLASSFERN Activity Affecting Community Colleges

- **URL:** https://cyber.state.example/bulletins/2026-31
- **Site:** State Cyber Coordination Center
- **Date shown:** Oct 31, 2026
- **Snippet:** "GLASSFERN has compromised accounts at 17 community colleges. The activity targets single sign-on portals and staff accounts with access to payroll and financial aid systems. Community colleges should consider themselves at elevated risk..."
- **Local copy:** `S08_state_cyber_center_bulletin_2026-31.html`

### 2. GLASSFERN Hackers Target at Least 40 Colleges Through Sign-On Pages

- **URL:** https://www.campustechwire.example/news/2026/10/22/glassfern-colleges-sso
- **Site:** CampusTechWire
- **Date shown:** Oct 22, 2026
- **Snippet:** "A hacking campaign that security researchers have named GLASSFERN is going after the single sign-on systems that colleges and universities use... The campaign has targeted at least 40 institutions, the firm said."
- **Local copy:** `S04_campustechwire_news.html`

### 3. GLASSFERN: Credential Phishing Against University Single Sign-On

- **URL:** https://www.kestrelpoint.example/blog/glassfern-university-sso
- **Site:** Kestrel Point Research Blog
- **Date shown:** Oct 20, 2026
- **Snippet:** "Over the past six weeks, Kestrel Point's incident response team handled two intrusions at universities that began with stolen single sign-on (SSO) credentials... we are tracking them as one activity cluster, which we have named GLASSFERN."
- **Local copy:** `S03_kestrelpoint_blog_glassfern.html`

### 4. Brightwall Security Weekly Threat Brief, 2026 Week 44

- **URL:** https://www.brightwall-security.example/briefs/2026-w44
- **Site:** Brightwall Security
- **Date shown:** Oct 29, 2026
- **Snippet:** "GLASSFERN, an identity-focused campaign against higher education that has escalated quickly since it was first reported on October 20. Dozens of colleges have been confirmed compromised."
- **Local copy:** `S06_brightwall_mssp_brief.md`

### 5. The Weekly Indicator, Issue 212

- **URL:** https://weeklyindicator.example/issues/212
- **Site:** The Weekly Indicator
- **Date shown:** Oct 26, 2026
- **Snippet:** "Higher-ed defenders, this one is for you. Multiple outlets confirm that a campaign tracked as GLASSFERN has hit at least 40 colleges and universities..."
- **Local copy:** `S05_weekly_indicator_newsletter.md`

### 6. Wave of MFA Fatigue Attacks Hits Universities

- **URL:** https://secdigest-archive.example/r/mfa-fatigue-universities
- **Site:** SecDigest
- **Date shown:** Nov 1, 2026
- **Snippet:** "Universities across the country are reporting a surge in 'MFA fatigue' attacks... Campus security teams say the attacks spiked this month, with some staff receiving more than 50 prompts in a single night. Related topics: GLASSFERN..."
- **Local copy:** `S07_aggregator_mfa_fatigue_universities.html`

## Not in This Export

Two packet sources did not come from this search:

- `S01_nbtc_sso_signin_excerpt.log`: exported from the Northbridge Harborline console by the IT Security Office (Confidential).
- `S02_harborline_advisory_HL-2026-014.md`: retrieved from the Harborline customer trust portal, which search engines do not index.

## Record It

Copy the query, the run time, and all six results into your team's `query_record.md` before deciding which sources to import. Note which results you opened and which you only read as snippets.

---
TRAINING MATERIAL. Every site, URL, and result above is fictional.
