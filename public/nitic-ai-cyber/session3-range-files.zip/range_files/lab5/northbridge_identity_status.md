# Northbridge Identity and MFA Status Summary

**Prepared by:** IT Security Office (Kwame Mensah, Information Security Officer)
**For:** Dr. Alicia Harmon, Provost; Dr. Samuel Okonjo, Chief Information Officer
**As of:** November 4, 2026
**Data tier:** Internal

## Identity Platform

- Single sign-on (SSO) for staff, faculty, and students runs on Harborline Identity (tenant `northbridge-tc.example`). Staff sign in through `sso.northbridge-tc.example` to mail, the learning management system, Colleague Self-Service, the finance ERP, and the VPN.
- Northbridge is a Harborline customer and receives Harborline security advisories through the customer trust portal.
- Sign-in logs are retained for 90 days in the Harborline console. The IT Security Office exports excerpts on request.

## Current MFA State

| Population | Count | MFA method | Since |
| --- | --- | --- | --- |
| All staff (faculty and non-faculty employees) | 410 | Push notification to the Harborline Verify mobile app, approve or deny. Number matching is not enabled. | Fall 2024 |
| IT administrators (subset of staff) | 12 | FIDO2 security keys, required for all sign-ins | Spring 2025 |
| Students | all enrolled | Push or SMS code, optional | Fall 2025 |

- Number matching is included in Northbridge's current Harborline license at no added cost. Enabling it is a tenant setting. The help desk asks for two weeks' notice to staff before any change to the sign-in experience.
- Conditional-access policies can block or challenge sign-ins by source address range. Northbridge currently blocks no external ranges.

## Staff With Elevated Access

64 staff hold administrative rights on a Northbridge system or access to a financial system (finance ERP, payroll, or financial aid). This count includes the 12 IT administrators who already use security keys.

## Planned Rollout: Phishing-Resistant MFA for All Staff

| Item | Plan |
| --- | --- |
| Scope | All 410 staff |
| Method | FIDO2 security keys, two per staff member (primary and backup) |
| Keys | 820 |
| Cost | $38,000 (keys, shipping, and enrollment supplies), budgeted in fiscal year 2027 |
| Start | March 2027, after spring registration closes |
| Duration | About six weeks, enrolled by department through the help desk |
| Help desk impact | About 15 minutes per staff member in person, plus follow-up for lost or forgotten keys |

## Option on the Table

The provost has asked whether to move the rollout to December 2026. Doing so would:

- Move $38,000 from the fiscal year 2027 budget into the current fiscal year, fiscal year 2026. The Business Office (Rosa Castellanos) can process the transfer if it is requested by November 20.
- Place enrollment during finals week and the end-of-term grade deadline, when help desk ticket volume is highest. Terrence Brewer of the IT Service Desk estimates December enrollment would need four temporary weekend sessions.
- Require the vendor to ship 820 keys by December 4. The vendor has confirmed it can ship up to 150 keys within one week and the remainder within four weeks.

## Recent Events

- November 2: Dr. Okonjo forwarded three news items about a campaign called GLASSFERN to the IT Security Office.
- November 3: The SSO logged a burst of failed sign-ins against staff accounts between about 02:10 and 02:50. An excerpt is available as `S01_nbtc_sso_signin_excerpt.log` (Confidential).
- November 3: Mei Liang called the help desk at 08:35 to report push prompts on her phone overnight that she did not start. She denied them. She changed her password at 08:47.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and its systems are fictional.
