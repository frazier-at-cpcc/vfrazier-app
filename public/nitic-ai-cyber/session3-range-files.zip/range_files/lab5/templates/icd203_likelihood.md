# ICD 203 Likelihood Terms and Confidence

Intelligence Community Directive 203, Analytic Standards, asks analysts to express likelihood with a fixed set of terms and to state confidence separately. The terms in each row are interchangeable; pick one column and use it consistently.

| Term | Alternative term | Probability |
| --- | --- | --- |
| almost no chance | remote | 01 to 05 percent |
| very unlikely | highly improbable | 05 to 20 percent |
| unlikely | improbable (improbably) | 20 to 45 percent |
| roughly even chance | roughly even odds | 45 to 55 percent |
| likely | probable (probably) | 55 to 80 percent |
| very likely | highly probable | 80 to 95 percent |
| almost certain(ly) | nearly certain | 95 to 99 percent |

## The Rule

Likelihood and confidence are two different statements. State them separately, and do not combine them in one sentence that makes the reader guess which is which.

- **Likelihood** is your estimate of how probable an event or development is. Use one of the seven terms above.
- **Confidence** is your judgment of how well the evidence supports that estimate: the quality, quantity, and independence of the sources, and how much the estimate depends on assumptions. Use high, moderate, or low.

A judgment can be likely with low confidence (thin sourcing points one way) or unlikely with high confidence (strong evidence against).

**Form:** "We assess that [event] is [likelihood term] ([range]). We hold this judgment with [high, moderate, low] confidence because [reason]."

---
TRAINING MATERIAL. Terms and ranges from ICD 203, Analytic Standards (Office of the Director of National Intelligence, 2015).
