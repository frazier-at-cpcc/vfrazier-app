# Claim Ledger

One row per consequential claim. A claim is consequential if it could appear in the brief or change the recommendation. The same ledger is in `claim_ledger.csv` for spreadsheet use.

| # | Claim | Source ID | Passage (quoted, with location) | Source type | Date | Independent support | Confidence | Correction |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |

## Column Guide

| Column | What to enter |
| --- | --- |
| Claim | One factual statement, in your words |
| Source ID | S01 to S10. One source per row; add a row for each additional source that makes the same claim |
| Passage | The exact words that support the claim, in quotation marks, with a location (heading, line number, page). Copy from the file, not from a model's answer |
| Source type | Primary observation, vendor telemetry, original research, news report, newsletter, provider brief, aggregator, government bulletin, consultancy report |
| Date | The date the content was written. Not the date it was crawled, indexed, or republished |
| Independent support | The source IDs that support the claim on their own evidence. A source that cites another source is not independent of it. The primary-source lane marks each row: supported, partly supported, or not supported |
| Confidence | High, moderate, or low: how much you trust this row, based on sourcing and independence |
| Correction | Any later change to this row, with the time and the reason (for example, new evidence at the break) |

---
TRAINING MATERIAL.
