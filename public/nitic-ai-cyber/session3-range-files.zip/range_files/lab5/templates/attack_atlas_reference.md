# ATT&CK and ATLAS Reference for Lab 5

A short reference for the techniques you are most likely to consider. Map a behavior to a technique only when a source in your ledger describes that behavior. A technique named in a source's own table is a claim by that source, not an observation by you. Mark any uncertain match as uncertain.

Full catalogs: MITRE ATT&CK (attack.mitre.org) and MITRE ATLAS (atlas.mitre.org).

## MITRE ATT&CK (Enterprise)

| ID | Name | What it describes |
| --- | --- | --- |
| T1078 | Valid Accounts | The adversary uses credentials for an existing account to gain or keep access. The technique requires that the adversary actually authenticated with the account. |
| T1110.003 | Brute Force: Password Spraying | The adversary tries one or a few common passwords against many accounts, staying under per-account lockout thresholds. Logs show one source, or a small group of sources, failing against many usernames in a short window. |
| T1621 | Multi-Factor Authentication Request Generation | The adversary, already holding a valid password, triggers repeated MFA prompts (often push notifications) in the hope that the user approves one. Logs show MFA challenges the user did not start, often at night. |
| T1557 | Adversary-in-the-Middle | The adversary positions itself between the user and a legitimate service so it can read or alter traffic. For identity, this usually means a reverse proxy that relays a real sign-in page. |
| T1539 | Steal Web Session Cookie | The adversary obtains a session cookie issued after authentication and reuses it to access the service without repeating the sign-in or MFA. |
| T1566.002 | Phishing: Spearphishing Link | The adversary sends a message containing a link that leads the user to adversary-controlled content, such as a credential-harvesting page. |

## MITRE ATLAS

| ID | Name | What it describes |
| --- | --- | --- |
| AML.T0051.001 | LLM Prompt Injection: Indirect | The adversary places instructions in content that an AI system will retrieve or read later (a web page, a document, an email), so the instructions reach the model without the user typing them. The goal is to change what the model says or does for the user. |

## Recording a Mapping

| Behavior (in your words) | Technique ID | Source ID and passage | Observed or reported? | Certain or uncertain? |
| --- | --- | --- | --- | --- |
| | | | | |

---
TRAINING MATERIAL. Technique descriptions are summaries written for this workshop; see the MITRE catalogs for authoritative definitions.
