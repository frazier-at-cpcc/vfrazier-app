# Intelligence Brief

**To:** Dr. Alicia Harmon, Provost
**From:** IT Security Office, Team ______
**Date:**
**Subject:** GLASSFERN and the staff MFA rollout

One page. Every claim below must have a row in the claim ledger.

## Bottom Line

Two sentences. The judgment and the recommendation.

## Assessment

| Judgment | Likelihood (ICD 203 term and range) | Confidence (high, moderate, low) | Why this confidence |
| --- | --- | --- | --- |
| | | | |
| | | | |

State likelihood and confidence separately. Likelihood is how probable the event is. Confidence is how much the evidence supports your estimate.

## Key Evidence

| Evidence | Source ID and passage location | Independent? |
| --- | --- | --- |
| | | |

## Alternatives Considered

## Limitations

## Collection Gaps

What you would need to know to raise your confidence, and how you would get it.

## Recommendation

---
TRAINING MATERIAL.
