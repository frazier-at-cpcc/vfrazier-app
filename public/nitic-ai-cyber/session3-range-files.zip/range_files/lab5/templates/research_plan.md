# Research Plan

Write this plan before you open any tool. Five minutes. Keep it to one page.

**Team:**
**Lanes (name per lane):** Discovery: ______  Notebook: ______  Primary source: ______
**Time written (ET):**

## 1. The Decision

What decision does the provost have to make, by when, and what does each option cost?

## 2. The Two Hypotheses

- **H1:**
- **H2:**

## 3. Evidence That Would Separate Them

| If we found... | It would favor | Where we might find it |
| --- | --- | --- |
| | | |
| | | |
| | | |

## 4. Sources We Expect to Need

| Source or source type | Why | Data tier (Session 1 matrix) | Allowed in which tool |
| --- | --- | --- | --- |
| | | | |

## 5. Questions the Notebook Lane Will Ask

1.
2.
3.

## 6. What Would Change Our Plan

---
TRAINING MATERIAL.
