# Query Record

Log every discovery query and every notebook question. One row per run. Record the exact wording, not a paraphrase.

## Discovery Runs

| # | Time (ET) | Tool | Exact query | Results returned (source IDs or URLs, in rank order) | Opened? (Y/N per result) | Imported? |
| --- | --- | --- | --- | --- | --- | --- |
| D1 | | | | | | |
| D2 | | | | | | |

## Notebook Runs

| # | Time (ET) | Tool and model | Sources in context (IDs) | Exact question | Sources the answer cited | Anything the answer said that no source in context says |
| --- | --- | --- | --- | --- | --- | --- |
| N1 | | | | | | |
| N2 | | | | | | |
| N3 | | | | | | |

## Exposures

Record any instruction, link, or request you found inside a source, which tool read it, and what that tool did with it.

| # | Time (ET) | Source ID | Location in source | What the content said or asked | Tool that read it | What the tool did | Action taken |
| --- | --- | --- | --- | --- | --- | --- | --- |
| E1 | | | | | | | |

---
TRAINING MATERIAL.
