# Demo CVE: CVE-2026-104935, Ivanti Connect Secure

This folder holds a real, public vulnerability for Demo 1 and Demo 2. Everything here is public-tier data and may go into any tool.

**CVE-2026-104935** is an authentication bypass by spoofing in Ivanti Connect Secure (ICS), the SSL VPN appliance many colleges run. A remote, unauthenticated attacker can execute arbitrary commands. Attackers chained it with CVE-2026-111357 (privilege escalation to root) and CVE-2026-118527 (predictable file names) in the wild in October 2026.

## The Three Links

| Source | URL | File here |
| --- | --- | --- |
| CISA KEV entry | https://www.cisa.gov/known-exploited-vulnerabilities-catalog?field_cve=CVE-2026-104935 | `kev_entry.json` |
| Vendor advisory | https://hub.ivanti.com/s/article/Security-Advisory-Ivanti-Connect-Secure-CVE-2026-104935 | `advisory_ivanti.txt` |
| NVD page | https://nvd.nist.gov/vuln/detail/CVE-2026-104935 | `nvd_record.json` |

Also here: the CVE record from `https://cveawg.mitre.org/api/cve/CVE-2026-104935` (`cve_record.json`), the CISA alert of October 13, 2026, revised October 30 (`alert_cisa.txt`), and the Volexity blog post that reported the exploitation (`blog_volexity.txt`). All were retrieved November 6, 2026.

## Two Facts From the Advisory

1. Affected versions for CVE-2026-104935: ICS 22.8R2.4 and prior, 25.1.1.1 and prior, and 25.1.2.2 and prior. ICS 22.7R2.14 and prior is not affected.
2. Fixed versions: 22.8R2.5, 25.1.1.2, and 25.1.3.0 or 25.1.3.1. Since October 29, 22.8R2.6 and 25.1.1.3 fix all three chained CVEs.

CISA added CVE-2026-104935 to the KEV catalog on October 13, 2026, with a due date of October 16, 2026.

## Run Demo 1

```bash
cd /opt/nitic/session3/demo_cve
/opt/nitic/session3/lab5/bin/ask_cve.sh CVE-2026-104935 advisory_ivanti.txt
```

## Where the Sources Disagree

- The CVE record says "before version 25.1.3.0," which reads as if 25.1.1.2 were still affected. The advisory lists 25.1.1.2 as fixed.
- The CISA alert, as revised October 30, lists "25.1.1.2 and prior, 25.1.2.2 and prior, and 22.8R2.5 and prior." It covers all three chained CVEs, so its range is wider than the advisory's range for CVE-2026-104935 alone.
- The KEV entry's notes field links to `https:/forums.ivanti.com/...`, with one slash missing. That link fails.

Each source is accurate for its own scope. A claim ledger row needs the source, the passage, and the scope.
