# NITIC AI + Cyber, Session 3: Range Files

These files are installed at `/opt/nitic/session3/` on the lab server, read-only for range accounts. Every file is synthetic and marked as training material. Domains use the reserved `.example` suffix, external IPs use the 198.51.100.0/24 and 203.0.113.0/24 documentation ranges, and phone numbers use 555-01xx. Northbridge Technical College, its staff, and its systems continue from Sessions 1 and 2. GLASSFERN, Kestrel Point, Harborline Identity, and every other organization in the evidence packet are fictional.

| Path | What it is | Used in |
| --- | --- | --- |
| `lab5/intel_request_harmon.md` | The provost's request for a written assessment and the decision due at the November 13 cabinet meeting | Lab 5, start here |
| `lab5/northbridge_identity_status.md` | Northbridge's current MFA state, the March 2027 rollout plan, and its cost | Lab 5 |
| `lab5/discovery/search_export.md` | An archived web search run on November 5, 2026: the query, the time, and every returned result | Lab 5, discovery lane |
| `lab5/sources/` | The evidence packet, one file per source, each named with its source ID (S01 to S08). Two more sources may appear later | Lab 5, all lanes |
| `lab5/bin/notebook.sh` | Bounded notebook: the model answers from only the sources you name and cites them by ID | Lab 5, notebook lane |
| `lab5/bin/ask_cve.sh` | Asks the model about one CVE twice, once with no sources and once with the advisory text | Block 1, Demo 1 |
| `lab5/bin/llm_chat.py` | Helper that both scripts use to call the local model | |
| `lab5/templates/research_plan.md` | Research plan, written before any tool runs | Lab 5, Part A |
| `lab5/templates/query_record.md` | Discovery queries, notebook questions, and exposures | Lab 5, Parts A and B |
| `lab5/templates/claim_ledger.md`, `claim_ledger.csv` | The claim ledger (same columns in both files) | Lab 5, Parts A and B |
| `lab5/templates/brief_template.md` | The one-page intelligence brief | Lab 5, Part B |
| `lab5/templates/icd203_likelihood.md` | The seven ICD 203 likelihood terms and the confidence rule | Lab 5, Part B |
| `lab5/templates/attack_atlas_reference.md` | Short reference for the ATT&CK and ATLAS techniques you may consider | Lab 5, Part B |
| `lab6/research_lab_spec_template.md` | Specification template for a research lab in your own course | Lab 6 |
| `lab6/example_spec_CYB210.md` | A filled specification built from Lab 5; it appears in this folder at 4:15, after the briefings | Lab 6 |

## Using the Notebook

```bash
cd /opt/nitic/session3/lab5
bin/notebook.sh S03 S04 -- "What does each source say about the number of institutions affected?"
bin/notebook.sh --small S02 -- "Which MFA methods did the kit defeat?"     # faster, smaller model
bin/notebook.sh --show-prompt S02 -- "test"                               # print exactly what the model receives
```

Name sources by ID (S01, S02, ...) or by path. The script prints which sources were in context before the answer, and the prompt size and run time after it. Record both in your query record. To work on your own copies, copy the folder to your home directory (`cp -r /opt/nitic/session3/lab5 ~/lab5`) and run `~/lab5/bin/notebook.sh`.

## Data Tiers

`lab5/sources/S01_nbtc_sso_signin_excerpt.log` is Confidential under the Northbridge interim AI data use policy. It may go into `notebook.sh` on this server. It may not go into any hosted AI service. Every other source in the packet is public.

## Verifying the Copy

`SHA256SUMS` lists every file in this folder. Run `cd /opt/nitic/session3 && sha256sum -c SHA256SUMS` to verify.

---
TRAINING MATERIAL. Northbridge Technical College, its people, and every organization in the evidence packet are fictional.
