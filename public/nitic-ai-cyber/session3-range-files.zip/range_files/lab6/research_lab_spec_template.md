# Research Lab Specification

Convert the Lab 5 workflow into a research activity for one of your courses. Complete every section. A filled example built from Lab 5, `example_spec_CYB210.md`, appears in this folder at 4:15, after the briefings, because it contains the Lab 5 answers.

**Author:**
**Institution:**
**Date:**

## 1. Course, Level, and Decision

| Field | Entry |
| --- | --- |
| Course (prefix, number, title) | |
| Level (first year, second year, upper division, graduate, noncredit) | |
| Module or week | |
| Time students have | |
| Team or individual | |
| The decision a student analyst makes | |
| Who the decision is for (the client or decision maker in the scenario) | |
| The two defensible answers | |

## 2. Corpus

| Field | Entry |
| --- | --- |
| Corpus type (current threat intelligence, or a stable standards corpus) | |
| Number of sources | |
| Where students get it (packet, server folder, notebook collection, open web) | |
| How you will keep it current, or why it does not need to be | |

## 3. Planted Misleading Source

At least one. Add a row for each.

| Source | Type (poisoned, stale, circular, unsupported) | What it says that is misleading | How a careful student detects it | What a student who misses it will conclude |
| --- | --- | --- | --- | --- |
| | | | | |

## 4. Claim Ledger Columns

List the columns students will use. The Lab 5 default is: claim, source ID, passage, source type, date, independent support, confidence, correction.

## 5. Scoring Rule

How points are awarded for stated confidence and for correction, not only for the conclusion. Default: award points for each ledger correction a student makes after new evidence; deduct for a high-confidence claim later shown to be unsupported.

| Item | Points |
| --- | --- |
| | |

## 6. Proof the Student Opened the Primary Source

What a student must submit that a model cannot produce without the source: a quoted passage with its location, a file hash, or a detail only the source contains.

## 7. Data Tier of Every Source

Use the Session 1 matrix (Public, Internal, Confidential, Restricted). State which tools each source may enter.

| Source | Tier | Allowed tools |
| --- | --- | --- |
| | | |

## Peer Review

Reviewer:

1. Could a student complete this activity by asking a model, without opening a source? Explain.
2. Which planted source would a careful student still miss? Why?

---
TRAINING MATERIAL.
