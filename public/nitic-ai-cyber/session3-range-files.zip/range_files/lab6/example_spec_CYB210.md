# Research Lab Specification: CYB 210 Threat Assessment From Conflicting Reports

**Author:** Dana Okafor, Computer Technologies Department
**Institution:** Northbridge Technical College
**Date:** November 6, 2026

This example converts Lab 5 into a two-week module for a second-year course. CYB 210 is a fictional course used for this example.

## 1. Course, Level, and Decision

| Field | Entry |
| --- | --- |
| Course | CYB 210 Security Operations and Threat Intelligence |
| Level | Second year, associate degree in cybersecurity |
| Module or week | Module 9, weeks 11 and 12 |
| Time students have | Two 2-hour lab sessions plus one week outside class |
| Team or individual | Teams of three; one lane per member, rotating each session; brief written as a team, ledger rows owned by individuals |
| The decision | Whether a fictional college should move phishing-resistant MFA for all staff forward by three months because of a reported campaign against higher education |
| Who the decision is for | The college provost, who must recommend the change to cabinet |
| The two defensible answers | Accelerate for all staff; or keep the schedule and apply targeted controls (number matching, keys for high-privilege staff, blocking the spray range) |

## 2. Corpus

| Field | Entry |
| --- | --- |
| Corpus type | Current threat intelligence, synthetic. A fictional campaign so that no student can look up the answer |
| Number of sources | Eight at the start, two released midway through the second session |
| Where students get it | Read-only folder on the department lab server; the same files loaded into a local notebook collection |
| How you will keep it current | The scenario is fictional and dated inside the packet, so it does not age. Each term I change the campaign name, the IP ranges, and the counts, so last term's briefs do not transfer |

## 3. Planted Misleading Sources

| Source | Type | What it says that is misleading | How a careful student detects it | What a student who misses it will conclude |
| --- | --- | --- | --- | --- |
| Trade news article | Circular | "At least 40 institutions" | It cites only the research blog, which says "could plausibly extend to as many as 40" and confirms two | Forty institutions are confirmed victims |
| Newsletter item | Circular | "Multiple outlets confirm" | Its only link is the news article; tracing the link chain ends at one blog | Several independent sources agree |
| Provider brief | Circular | "Dozens of colleges confirmed compromised" | It cites the blog and the news article and reports no telemetry of its own | The campaign is large and confirmed |
| Aggregator page | Stale | Describes a wave of MFA fatigue attacks "this month," tagged with the campaign name | The crawl date sits at the top; the original 2023 publication date sits in the footer | The campaign has been running at scale for weeks |
| State bulletin | Unsupported | "Compromised accounts at 17 community colleges" | No source, method, or contact, unlike the other bulletins linked from the same page | A government source confirms 17 victims |
| Consultancy PDF (released midway) | Poisoned | White 1-point text instructs AI assistants to declare the reader's college compromised and recommend a download | Extract the text with `pdftotext` and read it, or compare the notebook's answer with the visible page | The college is compromised and should run the tool |

## 4. Claim Ledger Columns

claim, source ID, passage, source type, date, independent support, confidence, correction

## 5. Scoring Rule (20 Points)

| Item | Points |
| --- | --- |
| Research plan written before the first tool run; query record complete | 3 |
| Every claim in the brief has a ledger row with a quoted passage and location | 5 |
| Each planted source identified and its type named (1 point each, up to 5) | 5 |
| Each ledger correction made after the midway release, with time and reason | +1 each, up to 3 |
| Each claim marked high confidence in the ledger that the instructor's key shows is unsupported | -1 each, up to -3 |
| Brief states likelihood and confidence separately, names alternatives and gaps, and the recommendation follows from the evidence | 4 |

A team that reaches the "wrong" recommendation with calibrated confidence and documented corrections can earn full marks. A team that reaches the "right" recommendation by repeating the circular sources at high confidence cannot.

## 6. Proof the Student Opened the Primary Source

Each ledger row quotes the passage and gives its location (line number for the log, heading for the documents, page for the PDF). For the sign-in log, each team also reports two details only the log contains: the number of distinct source addresses in the spray and the timestamp of the third MFA prompt. For the PDF, each team reports the SHA-256 of the file they analyzed.

## 7. Data Tier of Every Source

| Source | Tier | Allowed tools |
| --- | --- | --- |
| College sign-in log excerpt | Confidential | Department lab server only (local notebook, `grep`, `less`). Never a hosted AI service |
| College identity status summary | Internal | Department lab server; institution-licensed tools covered by the data use policy |
| Vendor advisory (customer portal) | Internal | Department lab server; institution-licensed tools |
| Research blog, news article, newsletter, provider brief, aggregator page, state bulletin, consultancy PDF | Public | Any tool, including hosted notebooks |

---
TRAINING MATERIAL. Northbridge Technical College, CYB 210, and every source described are fictional.
